# V2.3.1 Mix Fix

- Fixed Smart Mix / Smart Shuffle freezing on very large (8k+) libraries by replacing the O(n²) shuffle path with an artist-bucket algorithm.
- Mix playback now skips temporarily unavailable restored iTunes items instead of stopping silently on the first track.
- Hard Rap and Gym mixes now work even when iTunes files do not contain BPM metadata.
- Chill / R&B filtering no longer repeatedly rebuilds/searches the Late Night array.
- iPhone Music sync now stores release year when available, so This Year can populate.
- No automatic full iTunes resync on app launch; cached library behavior from V2.3 remains.

# V2.2 Performance Patch

- Fast iTunes/iPhone Music sync for very large libraries (8,000+ songs)
- Stops publishing the track array once per song; publishes once after indexing
- Removes per-track filesystem size checks during Media Library sync
- Removes 900x900 artwork rendering/writes during sync
- Loads artwork lazily only for visible rows and player screens
- Adds bounded in-memory album-art cache
- Reduces sync status UI updates from every 50 tracks to every 250 tracks

# LocalRapPlayer 2.1 — iTunes / iPhone Music Sync

- Reads songs already synced to the iPhone with iTunes via `MPMediaLibrary`.
- One-time Media Library permission prompt.
- Automatically refreshes the synced iPhone Music library on app launch after permission is granted.
- Manual **Sync iPhone Music** button in Library and the + menu.
- Does not duplicate audio into the app sandbox; media-library songs are referenced by persistent ID.
- Imports title, artist, album, genre, track/disc number, duration, BPM when available, and album artwork.
- Existing Favorites, ratings, play counts and listening stats are preserved across resyncs.
- Apple Music subscription/DRM-protected or cloud-only tracks that do not expose a local asset URL are skipped.
- Synced songs can use EQ, crossfade and local analysis when iOS exposes a readable local audio asset.
- Hiding a synced song keeps it out of later rescans; **Restore Hidden Synced Songs** brings them back.

# Build Fix 1

Fixed compile errors found in GitHub Actions/Xcode 26.6 logs:

- Removed redundant optional bindings in `MusicLibrary.swift` for AVMetadataItem async loads.
- Replaced mixed `.tint` / `.secondary` ShapeStyle ternaries with explicit `Color` values in `NowPlayingView.swift`.
- Fixed weak `self` capture lifetime/mutation issue in crossfade task in `PlayerManager.swift`.

The existing `project.yml` and folder layout are unchanged.


## V2.3 — Instant Launch / Manual iTunes Sync
- Removed full iPhone/iTunes library rescan from app startup.
- Cached synced songs load immediately on launch.
- Full iTunes refresh only happens when **Sync iPhone Music** is tapped.
- Added last-sync timestamp and clearer cached-library status.
- Designed for very large restored/synced libraries (8,000+ songs).
