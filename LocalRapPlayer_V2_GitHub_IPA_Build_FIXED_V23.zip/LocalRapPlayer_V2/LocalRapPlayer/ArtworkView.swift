import SwiftUI
import UIKit

struct ArtworkView: View {
    let track: Track
    var size: CGFloat = 52
    @State private var mediaImage: UIImage?

    var body: some View {
        Group {
            if let url = AppPaths.artworkURL(for: track),
               let data = try? Data(contentsOf: url),
               let uiImage = UIImage(data: data) {
                Image(uiImage: uiImage).resizable().scaledToFill()
            } else if let mediaImage {
                Image(uiImage: mediaImage).resizable().scaledToFill()
            } else {
                ZStack {
                    RoundedRectangle(cornerRadius: size * 0.18).fill(.quaternary)
                    Image(systemName: "music.note")
                        .font(.system(size: size * 0.35, weight: .semibold))
                        .foregroundStyle(.secondary)
                }
            }
        }
        .frame(width: size, height: size)
        .clipShape(RoundedRectangle(cornerRadius: size * 0.18, style: .continuous))
        .task(id: "\(track.id.uuidString)-\(Int(size))") {
            guard track.sourceKind == .mediaLibrary else { return }
            // Load cover art only when the row/player is actually on screen.
            mediaImage = await MainActor.run {
                MediaLibrarySupport.artworkImage(
                    for: track,
                    size: CGSize(width: min(size * 2.2, 900), height: min(size * 2.2, 900))
                )
            }
        }
    }
}
