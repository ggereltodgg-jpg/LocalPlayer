// Add this file to a NEW Widget Extension target, not the main app target.
// To show real shared library data, enable an App Group for both targets and mirror
// a small "recently played" snapshot into the shared UserDefaults suite.
import WidgetKit
import SwiftUI

struct RecentMusicEntry: TimelineEntry {
    let date: Date
    let title: String
    let artist: String
}

struct RecentMusicProvider: TimelineProvider {
    func placeholder(in context: Context) -> RecentMusicEntry { .init(date: Date(), title: "FE!N", artist: "Travis Scott") }
    func getSnapshot(in context: Context, completion: @escaping (RecentMusicEntry) -> Void) { completion(placeholder(in: context)) }
    func getTimeline(in context: Context, completion: @escaping (Timeline<RecentMusicEntry>) -> Void) {
        let defaults = UserDefaults(suiteName: "group.com.yourname.LocalRapPlayer")
        let entry = RecentMusicEntry(date: Date(), title: defaults?.string(forKey: "widgetTitle") ?? "LocalRapPlayer", artist: defaults?.string(forKey: "widgetArtist") ?? "Recently Played")
        completion(Timeline(entries: [entry], policy: .after(Date().addingTimeInterval(900))))
    }
}

struct RecentMusicWidgetView: View {
    var entry: RecentMusicEntry
    var body: some View {
        VStack(alignment: .leading, spacing: 6) {
            Image(systemName: "music.note").font(.title2)
            Text(entry.title).font(.headline).lineLimit(1)
            Text(entry.artist).font(.caption).foregroundStyle(.secondary).lineLimit(1)
        }.containerBackground(.fill.tertiary, for: .widget)
    }
}

struct RecentMusicWidget: Widget {
    let kind = "RecentMusicWidget"
    var body: some WidgetConfiguration {
        StaticConfiguration(kind: kind, provider: RecentMusicProvider()) { entry in RecentMusicWidgetView(entry: entry) }
            .configurationDisplayName("Recently Played")
            .description("Shows the latest LocalRapPlayer song.")
            .supportedFamilies([.systemSmall, .systemMedium])
    }
}


@main
struct LocalRapPlayerWidgets: WidgetBundle {
    var body: some Widget { RecentMusicWidget() }
}
