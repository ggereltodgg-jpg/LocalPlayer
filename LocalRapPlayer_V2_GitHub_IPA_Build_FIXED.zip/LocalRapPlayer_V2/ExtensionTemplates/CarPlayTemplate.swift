// Reference template only. Full CarPlay audio apps require Apple's CarPlay Audio entitlement.
// Add the CarPlay capability/scene only if your developer account is approved for it.
import CarPlay
import UIKit

final class CarPlaySceneDelegate: UIResponder, CPTemplateApplicationSceneDelegate {
    func templateApplicationScene(_ templateApplicationScene: CPTemplateApplicationScene,
                                  didConnect interfaceController: CPInterfaceController) {
        let item = CPListItem(text: "Open LocalRapPlayer", detailText: "Use Now Playing controls for local music")
        let section = CPListSection(items: [item])
        let list = CPListTemplate(title: "LocalRapPlayer", sections: [section])
        interfaceController.setRootTemplate(list, animated: true, completion: nil)
    }
}
