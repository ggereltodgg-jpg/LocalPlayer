// iOS already presents media apps in Lock Screen / Control Center and supported Dynamic Island
// surfaces through MPNowPlayingInfoCenter + MPRemoteCommandCenter, which the main target uses.
// A custom Live Activity is intentionally not duplicated here; for a music player, system Now Playing
// is the correct first-line integration and avoids running a parallel playback status surface.
