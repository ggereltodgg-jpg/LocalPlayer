# Windows 11 → iPhone IPA build

This package now includes a GitHub Actions workflow that builds an **unsigned iPhone IPA** on a GitHub-hosted macOS runner. You do not need to own a Mac for the build step.

## On Windows 11
1. Extract this ZIP.
2. Create a **private** GitHub repository.
3. Upload the **contents of `LocalRapPlayer_V2`** to the repository root. The repository root must contain `project.yml`, `LocalRapPlayer/`, and `.github/`.
4. Open the repository → **Actions** → **Build iPhone IPA** → **Run workflow**.
5. Wait for the build to finish.
6. Open the completed run → **Artifacts** → download `LocalRapPlayer-unsigned-IPA`.
7. Extract the downloaded artifact. Inside is `LocalRapPlayer_unsigned.ipa`.

## Install on iPhone from Windows
Use AltStore/AltServer or another legitimate sideloading tool that signs the IPA with your own Apple ID. The GitHub artifact is intentionally unsigned, so it cannot be installed by tapping it directly.

## Important
- A real iPhone app binary can only be compiled against Apple's iOS SDK on macOS/Xcode. The GitHub workflow supplies that macOS build machine in the cloud.
- If the build fails, download the `xcodebuild-log` artifact and share it in ChatGPT so the source can be fixed.
- CarPlay and widget templates are not included in the main app target because they require separate targets and, for some capabilities, Apple entitlements.
