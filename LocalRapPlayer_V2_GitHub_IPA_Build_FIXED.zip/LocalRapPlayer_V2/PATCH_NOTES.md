# LocalRapPlayer 2.1 — iTunes / iPhone Music Sync

- Reads songs already synced to the iPhone with iTunes via `MPMediaLibrary`.
- One-time Media Library permission prompt.
- Automatically refreshes the synced iPhone Music library on app launch after permission is granted.
- Manual **Sync iPhone Music** button in Library and the + menu.
- Does not duplicate audio into the app sandbox; media-library songs are referenced by persistent ID.
- Imports title, artist, album, genre, track/disc number, duration, BPM when available, and album artwork.
- Existing Favorites, ratings, play counts and listening stats are preserved across resyncs.
- Apple Music subscription/DRM-protected or cloud-only tracks that do not expose a local asset URL are skipped.
- Synced songs can use EQ, crossfade and local analysis when iOS exposes a readable local audio asset.
- Hiding a synced song keeps it out of later rescans; **Restore Hidden Synced Songs** brings them back.

# Build Fix 1

Fixed compile errors found in GitHub Actions/Xcode 26.6 logs:

- Removed redundant optional bindings in `MusicLibrary.swift` for AVMetadataItem async loads.
- Replaced mixed `.tint` / `.secondary` ShapeStyle ternaries with explicit `Color` values in `NowPlayingView.swift`.
- Fixed weak `self` capture lifetime/mutation issue in crossfade task in `PlayerManager.swift`.

The existing `project.yml` and folder layout are unchanged.
