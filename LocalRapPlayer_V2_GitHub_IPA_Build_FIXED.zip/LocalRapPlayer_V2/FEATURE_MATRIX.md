# LocalRapPlayer V2 feature matrix

## In the main app source

- Local M4A / MP3 / AAC / FLAC / WAV / AIFF / CAF import
- Recursive folder import for large libraries
- Embedded title / artist / album / artwork metadata
- Song / artist / album / folder browsing
- Fast in-app search
- Editable playlists
- iTunes XML and M3U/M3U8 playlist import
- Favorites and 1–5 star ratings
- Queue with Play Next / Play Later / reorder / delete
- Smart Shuffle with configurable artist-spacing
- Smart mixes: Trap Run, Late Night, Hard Rap, Gym, Chill/R&B, K-Rap, current year, Most Played, Recently Played, Never Played, Recently Added
- AVAudioEngine playback
- 10-band EQ presets: Flat, Rap, Bass Boost, Vocal, R&B, Car
- Crossfade with two player nodes
- Normalization using locally estimated replay-gain value
- Background audio
- Lock Screen / Control Center metadata and remote controls
- Bluetooth A2DP and AirPlay audio session support
- Sleep timer
- In-app Car Mode
- Synced `.lrc` lyric import and seek-by-lyric-line
- Metadata editor (app database metadata; does not rewrite original file tags)
- Embedded artwork recovery
- Duplicate finder
- Missing-file checker
- Local BPM estimate
- Local musical-key estimate
- Local loudness / replay-gain estimate
- Listening stats: play count, skip count, total listening time, top songs/artists
- Backup / restore for favorites, stats and playlists
- Dark / Light / System theme
- Album-color preference setting hook
- Face ID / device-owner authentication lock
- Alternate app icon hook (`RapIcon` asset required in Xcode)

## System features that need an extra target / entitlement

- Home Screen widget: template included in `ExtensionTemplates/RecentMusicWidget.swift`. Create a Widget Extension and App Group in Xcode.
- CarPlay: template included, but a real CarPlay audio app requires the CarPlay Audio entitlement from Apple.
- Dynamic Island: the main app already feeds iOS Now Playing. iOS decides when/where the media surface is shown. A duplicate custom Live Activity is intentionally not used.

## Notes

BPM and key detection are lightweight on-device estimates for sorting and smart mixes. They are not intended to replace DJ/studio analysis software.

Crossfade is disabled effectively when set to 0 seconds. Gapless-style immediate handoff remains available at track end. True sample-perfect gapless behavior can vary with encoded source files.
