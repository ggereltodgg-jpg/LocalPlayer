import Foundation

struct LyricLine: Identifiable, Hashable {
    let id = UUID()
    let time: Double
    let text: String
}

enum LRCParser {
    static func parse(_ text: String) -> [LyricLine] {
        var output: [LyricLine] = []
        let regex = try? NSRegularExpression(pattern: #"\[(\d{1,2}):(\d{2})(?:[\.:](\d{1,3}))?\]"#)
        for line in text.components(separatedBy: .newlines) {
            let ns = line as NSString
            let matches = regex?.matches(in: line, range: NSRange(location: 0, length: ns.length)) ?? []
            let lyricText: String = {
                guard let last = matches.last else { return line.trimmingCharacters(in: .whitespaces) }
                let start = NSMaxRange(last.range)
                return ns.substring(from: start).trimmingCharacters(in: .whitespaces)
            }()
            for match in matches {
                let min = Double(ns.substring(with: match.range(at: 1))) ?? 0
                let sec = Double(ns.substring(with: match.range(at: 2))) ?? 0
                var frac = 0.0
                let r = match.range(at: 3)
                if r.location != NSNotFound {
                    let raw = ns.substring(with: r)
                    frac = (Double(raw) ?? 0) / pow(10.0, Double(raw.count))
                }
                output.append(LyricLine(time: min * 60 + sec + frac, text: lyricText))
            }
        }
        return output.sorted { $0.time < $1.time }
    }
}
