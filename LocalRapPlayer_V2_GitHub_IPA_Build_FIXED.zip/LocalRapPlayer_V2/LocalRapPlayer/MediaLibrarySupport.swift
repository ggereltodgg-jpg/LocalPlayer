import Foundation
import MediaPlayer
import UIKit

@MainActor
enum MediaLibrarySupport {
    private static var itemCache: [UInt64: MPMediaItem] = [:]

    static func cache(_ items: [MPMediaItem]) {
        itemCache.removeAll(keepingCapacity: true)
        for item in items {
            itemCache[UInt64(item.persistentID)] = item
        }
    }

    static func item(for persistentID: UInt64) -> MPMediaItem? {
        if let cached = itemCache[persistentID] { return cached }
        let query = MPMediaQuery.songs()
        let predicate = MPMediaPropertyPredicate(
            value: NSNumber(value: persistentID),
            forProperty: MPMediaItemPropertyPersistentID
        )
        query.addFilterPredicate(predicate)
        let item = query.items?.first
        if let item { itemCache[persistentID] = item }
        return item
    }

    static func audioURL(for track: Track) -> URL? {
        switch track.sourceKind {
        case .importedFile:
            return AppPaths.audioURL(for: track)
        case .mediaLibrary:
            guard let persistentID = track.mediaPersistentID,
                  let item = item(for: persistentID),
                  !item.hasProtectedAsset else { return nil }
            return item.assetURL
        }
    }

    static func artworkData(for track: Track, size: CGSize = CGSize(width: 900, height: 900)) -> Data? {
        guard track.sourceKind == .mediaLibrary,
              let persistentID = track.mediaPersistentID,
              let artwork = item(for: persistentID)?.artwork,
              let image = artwork.image(at: size) else { return nil }
        return image.jpegData(compressionQuality: 0.9)
    }
}
