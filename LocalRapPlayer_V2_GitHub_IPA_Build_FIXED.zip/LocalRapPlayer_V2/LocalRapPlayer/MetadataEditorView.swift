import SwiftUI

struct MetadataEditorView: View {
    let track: Track
    @ObservedObject var library: MusicLibrary
    @Environment(\.dismiss) private var dismiss
    @State private var title: String
    @State private var artist: String
    @State private var album: String
    @State private var genre: String
    @State private var year: String
    @State private var bpm: String
    @State private var key: String

    init(track: Track, library: MusicLibrary) {
        self.track = track; self.library = library
        _title = State(initialValue: track.title); _artist = State(initialValue: track.artist); _album = State(initialValue: track.album); _genre = State(initialValue: track.genre)
        _year = State(initialValue: track.year.map(String.init) ?? ""); _bpm = State(initialValue: track.bpm.map { String(format: "%.1f", $0) } ?? ""); _key = State(initialValue: track.musicalKey ?? "")
    }

    var body: some View {
        NavigationStack {
            Form {
                Section("Metadata") {
                    TextField("Title", text: $title); TextField("Artist", text: $artist); TextField("Album", text: $album); TextField("Genre", text: $genre)
                    TextField("Year", text: $year).keyboardType(.numberPad)
                    TextField("BPM", text: $bpm).keyboardType(.decimalPad)
                    TextField("Key", text: $key)
                }
                Section { Text("Edits are stored in LocalRapPlayer's library database. The original audio file bytes are not rewritten.").font(.footnote).foregroundStyle(.secondary) }
            }
            .navigationTitle("Edit Song")
            .toolbar {
                ToolbarItem(placement: .cancellationAction) { Button("Cancel") { dismiss() } }
                ToolbarItem(placement: .confirmationAction) {
                    Button("Save") {
                        library.updateMetadata(track.id, title: title, artist: artist, album: album, genre: genre, year: Int(year), bpm: Double(bpm), key: key.isEmpty ? nil : key)
                        dismiss()
                    }
                }
            }
        }
    }
}
