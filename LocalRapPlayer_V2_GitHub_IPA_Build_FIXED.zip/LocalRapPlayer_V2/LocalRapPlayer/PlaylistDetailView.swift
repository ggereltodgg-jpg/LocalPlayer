import SwiftUI

struct PlaylistDetailView: View {
    let playlist: Playlist
    @ObservedObject var library: MusicLibrary
    @ObservedObject var playlists: PlaylistStore
    @ObservedObject var player: PlayerManager

    private var livePlaylist: Playlist? { playlists.playlists.first(where: { $0.id == playlist.id }) }
    private var tracks: [Track] { (livePlaylist?.trackIDs ?? []).compactMap { id in library.tracks.first(where: { $0.id == id }) } }

    var body: some View {
        List {
            Section {
                HStack {
                    Button { player.playQueue(tracks) } label: { Label("Play", systemImage: "play.fill") }.buttonStyle(.borderedProminent)
                    Button { player.playQueue(tracks, smartShuffle: true) } label: { Label("Smart Shuffle", systemImage: "shuffle") }.buttonStyle(.bordered)
                }
            }
            ForEach(tracks) { track in
                HStack {
                    SongRow(track: track, isCurrent: player.currentTrack?.id == track.id, isPlaying: player.isPlaying).onTapGesture { player.play(track, in: tracks) }
                    Spacer()
                    Button(role: .destructive) { playlists.remove(track.id, from: playlist.id) } label: { Image(systemName: "minus.circle") }
                }
            }
            .onMove { source, dest in playlists.moveTracks(in: playlist.id, from: source, to: dest) }
        }
        .environment(\.editMode, .constant(.active))
        .navigationTitle(livePlaylist?.name ?? playlist.name)
        .safeAreaInset(edge: .bottom) { MiniPlayerView(player: player) }
    }
}
