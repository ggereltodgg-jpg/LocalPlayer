import Foundation
import SwiftUI

@MainActor
final class PlaylistStore: ObservableObject {
    @Published private(set) var playlists: [Playlist] = []

    init() { load() }

    func create(name: String, trackIDs: [UUID] = []) {
        let trimmed = name.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmed.isEmpty else { return }
        playlists.append(Playlist(name: trimmed, trackIDs: trackIDs))
        save()
    }

    func rename(_ playlist: Playlist, to name: String) {
        guard let i = playlists.firstIndex(where: { $0.id == playlist.id }) else { return }
        playlists[i].name = name
        playlists[i].updatedAt = Date()
        save()
    }

    func delete(_ playlist: Playlist) {
        playlists.removeAll { $0.id == playlist.id }
        save()
    }

    func add(_ trackID: UUID, to playlistID: UUID) {
        guard let i = playlists.firstIndex(where: { $0.id == playlistID }) else { return }
        guard !playlists[i].trackIDs.contains(trackID) else { return }
        playlists[i].trackIDs.append(trackID)
        playlists[i].updatedAt = Date()
        save()
    }

    func remove(_ trackID: UUID, from playlistID: UUID) {
        guard let i = playlists.firstIndex(where: { $0.id == playlistID }) else { return }
        playlists[i].trackIDs.removeAll { $0 == trackID }
        playlists[i].updatedAt = Date()
        save()
    }

    func moveTracks(in playlistID: UUID, from offsets: IndexSet, to destination: Int) {
        guard let i = playlists.firstIndex(where: { $0.id == playlistID }) else { return }
        playlists[i].trackIDs.move(fromOffsets: offsets, toOffset: destination)
        playlists[i].updatedAt = Date()
        save()
    }

    func replaceAll(_ newPlaylists: [Playlist]) {
        playlists = newPlaylists
        save()
    }

    func appendImported(name: String, trackIDs: [UUID]) {
        let base = name.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty ? "Imported Playlist" : name
        playlists.append(Playlist(name: base, trackIDs: trackIDs))
        save()
    }

    private func load() {
        guard let data = try? Data(contentsOf: AppPaths.playlistsFile),
              let decoded = try? JSONDecoder().decode([Playlist].self, from: data) else { return }
        playlists = decoded
    }

    private func save() {
        guard let data = try? JSONEncoder().encode(playlists) else { return }
        try? data.write(to: AppPaths.playlistsFile, options: .atomic)
    }
}
