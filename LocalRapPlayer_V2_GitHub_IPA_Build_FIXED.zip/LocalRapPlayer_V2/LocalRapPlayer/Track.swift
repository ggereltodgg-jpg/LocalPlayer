import Foundation

struct Track: Identifiable, Codable, Hashable {
    let id: UUID
    var title: String
    var artist: String
    var album: String
    var albumArtist: String
    var genre: String
    var year: Int?
    var trackNumber: Int?
    var discNumber: Int?
    var duration: Double
    var fileName: String
    var originalFileName: String
    var relativeSourcePath: String?
    var fileSize: Int64
    var artworkFileName: String?
    var lyricsFileName: String?
    var isFavorite: Bool
    var rating: Int
    var playCount: Int
    var skipCount: Int
    var totalListenSeconds: Double
    var lastPlayed: Date?
    var dateAdded: Date
    var bpm: Double?
    var musicalKey: String?
    var replayGainDB: Double?

    init(
        id: UUID = UUID(),
        title: String,
        artist: String,
        album: String = "",
        albumArtist: String = "",
        genre: String = "",
        year: Int? = nil,
        trackNumber: Int? = nil,
        discNumber: Int? = nil,
        duration: Double = 0,
        fileName: String,
        originalFileName: String,
        relativeSourcePath: String? = nil,
        fileSize: Int64,
        artworkFileName: String? = nil,
        lyricsFileName: String? = nil,
        isFavorite: Bool = false,
        rating: Int = 0,
        playCount: Int = 0,
        skipCount: Int = 0,
        totalListenSeconds: Double = 0,
        lastPlayed: Date? = nil,
        dateAdded: Date = Date(),
        bpm: Double? = nil,
        musicalKey: String? = nil,
        replayGainDB: Double? = nil
    ) {
        self.id = id
        self.title = title
        self.artist = artist
        self.album = album
        self.albumArtist = albumArtist
        self.genre = genre
        self.year = year
        self.trackNumber = trackNumber
        self.discNumber = discNumber
        self.duration = duration
        self.fileName = fileName
        self.originalFileName = originalFileName
        self.relativeSourcePath = relativeSourcePath
        self.fileSize = fileSize
        self.artworkFileName = artworkFileName
        self.lyricsFileName = lyricsFileName
        self.isFavorite = isFavorite
        self.rating = rating
        self.playCount = playCount
        self.skipCount = skipCount
        self.totalListenSeconds = totalListenSeconds
        self.lastPlayed = lastPlayed
        self.dateAdded = dateAdded
        self.bpm = bpm
        self.musicalKey = musicalKey
        self.replayGainDB = replayGainDB
    }

    private enum CodingKeys: String, CodingKey {
        case id, title, artist, album, albumArtist, genre, year, trackNumber, discNumber
        case duration, fileName, originalFileName, relativeSourcePath, fileSize
        case artworkFileName, lyricsFileName, isFavorite, rating, playCount, skipCount
        case totalListenSeconds, lastPlayed, dateAdded, bpm, musicalKey, replayGainDB
    }

    init(from decoder: Decoder) throws {
        let c = try decoder.container(keyedBy: CodingKeys.self)
        id = try c.decodeIfPresent(UUID.self, forKey: .id) ?? UUID()
        title = try c.decodeIfPresent(String.self, forKey: .title) ?? "Unknown Title"
        artist = try c.decodeIfPresent(String.self, forKey: .artist) ?? "Unknown Artist"
        album = try c.decodeIfPresent(String.self, forKey: .album) ?? ""
        albumArtist = try c.decodeIfPresent(String.self, forKey: .albumArtist) ?? ""
        genre = try c.decodeIfPresent(String.self, forKey: .genre) ?? ""
        year = try c.decodeIfPresent(Int.self, forKey: .year)
        trackNumber = try c.decodeIfPresent(Int.self, forKey: .trackNumber)
        discNumber = try c.decodeIfPresent(Int.self, forKey: .discNumber)
        duration = try c.decodeIfPresent(Double.self, forKey: .duration) ?? 0
        fileName = try c.decodeIfPresent(String.self, forKey: .fileName) ?? ""
        originalFileName = try c.decodeIfPresent(String.self, forKey: .originalFileName) ?? fileName
        relativeSourcePath = try c.decodeIfPresent(String.self, forKey: .relativeSourcePath)
        fileSize = try c.decodeIfPresent(Int64.self, forKey: .fileSize) ?? 0
        artworkFileName = try c.decodeIfPresent(String.self, forKey: .artworkFileName)
        lyricsFileName = try c.decodeIfPresent(String.self, forKey: .lyricsFileName)
        isFavorite = try c.decodeIfPresent(Bool.self, forKey: .isFavorite) ?? false
        rating = try c.decodeIfPresent(Int.self, forKey: .rating) ?? 0
        playCount = try c.decodeIfPresent(Int.self, forKey: .playCount) ?? 0
        skipCount = try c.decodeIfPresent(Int.self, forKey: .skipCount) ?? 0
        totalListenSeconds = try c.decodeIfPresent(Double.self, forKey: .totalListenSeconds) ?? 0
        lastPlayed = try c.decodeIfPresent(Date.self, forKey: .lastPlayed)
        dateAdded = try c.decodeIfPresent(Date.self, forKey: .dateAdded) ?? Date()
        bpm = try c.decodeIfPresent(Double.self, forKey: .bpm)
        musicalKey = try c.decodeIfPresent(String.self, forKey: .musicalKey)
        replayGainDB = try c.decodeIfPresent(Double.self, forKey: .replayGainDB)
    }
}
