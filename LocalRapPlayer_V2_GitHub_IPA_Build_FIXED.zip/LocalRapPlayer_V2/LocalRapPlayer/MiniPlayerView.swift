import SwiftUI

struct MiniPlayerView: View {
    @ObservedObject var player: PlayerManager
    @State private var showNowPlaying = false

    var body: some View {
        if let track = player.currentTrack {
            HStack(spacing: 10) {
                ArtworkView(track: track, size: 44)
                VStack(alignment: .leading, spacing: 2) {
                    Text(track.title).font(.subheadline.weight(.semibold)).lineLimit(1)
                    Text(track.artist).font(.caption).foregroundStyle(.secondary).lineLimit(1)
                }
                Spacer()
                Button(action: player.togglePlayPause) { Image(systemName: player.isPlaying ? "pause.fill" : "play.fill").font(.title3) }
                Button { player.next() } label: { Image(systemName: "forward.fill").font(.title3) }
            }
            .padding(.horizontal, 12).padding(.vertical, 8)
            .background(.ultraThinMaterial)
            .clipShape(RoundedRectangle(cornerRadius: 16, style: .continuous))
            .padding(.horizontal, 8)
            .onTapGesture { showNowPlaying = true }
            .sheet(isPresented: $showNowPlaying) { NowPlayingView(player: player) }
        }
    }
}
