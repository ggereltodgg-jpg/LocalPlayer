import Foundation

struct AppPaths {
    static let fm = FileManager.default

    static var applicationSupport: URL {
        let base = fm.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0]
        try? fm.createDirectory(at: base, withIntermediateDirectories: true)
        return base
    }

    static var musicDirectory: URL {
        let url = applicationSupport.appendingPathComponent("ImportedMusic", isDirectory: true)
        try? fm.createDirectory(at: url, withIntermediateDirectories: true)
        return url
    }

    static var artworkDirectory: URL {
        let url = applicationSupport.appendingPathComponent("Artwork", isDirectory: true)
        try? fm.createDirectory(at: url, withIntermediateDirectories: true)
        return url
    }

    static var lyricsDirectory: URL {
        let url = applicationSupport.appendingPathComponent("Lyrics", isDirectory: true)
        try? fm.createDirectory(at: url, withIntermediateDirectories: true)
        return url
    }

    static var exportDirectory: URL {
        let url = fm.urls(for: .cachesDirectory, in: .userDomainMask)[0].appendingPathComponent("Exports", isDirectory: true)
        try? fm.createDirectory(at: url, withIntermediateDirectories: true)
        return url
    }

    static var libraryFile: URL { applicationSupport.appendingPathComponent("library.json") }
    static var playlistsFile: URL { applicationSupport.appendingPathComponent("playlists.json") }

    static func audioURL(for track: Track) -> URL {
        musicDirectory.appendingPathComponent(track.fileName)
    }

    static func artworkURL(for track: Track) -> URL? {
        guard let name = track.artworkFileName else { return nil }
        return artworkDirectory.appendingPathComponent(name)
    }

    static func lyricsURL(for track: Track) -> URL? {
        guard let name = track.lyricsFileName else { return nil }
        return lyricsDirectory.appendingPathComponent(name)
    }
}
