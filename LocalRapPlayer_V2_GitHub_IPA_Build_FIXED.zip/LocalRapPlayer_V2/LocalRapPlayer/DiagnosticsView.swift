import SwiftUI

struct DiagnosticsView: View {
    @ObservedObject var library: MusicLibrary
    @ObservedObject var playlists: PlaylistStore
    @ObservedObject var player: PlayerManager

    var body: some View {
        List {
            Section("Library Health") {
                NavigationLink("Duplicates (\(library.duplicateGroups.count) groups)") { DuplicateView(library: library, playlists: playlists, player: player) }
                NavigationLink("Missing Files (\(library.missingFiles.count))") { MissingFilesView(library: library) }
            }
            Section("Audio Analysis") {
                Button("Analyze 25 Unanalyzed Songs") { Task { await library.analyzeAllMissing(limit: 25) } }
                Button("Analyze All Missing BPM / Key / Loudness") { Task { await library.analyzeAllMissing() } }
                if !library.analysisProgress.isEmpty { Text(library.analysisProgress).font(.footnote).foregroundStyle(.secondary) }
            }
            Section { Text("BPM/key detection is a lightweight local estimate intended for smart playlists and DJ-style ordering, not studio-grade music analysis.").font(.footnote).foregroundStyle(.secondary) }
        }.navigationTitle("Library Tools")
    }
}

private struct DuplicateView: View {
    @ObservedObject var library: MusicLibrary
    @ObservedObject var playlists: PlaylistStore
    @ObservedObject var player: PlayerManager
    var body: some View {
        List {
            ForEach(Array(library.duplicateGroups.enumerated()), id: \.offset) { _, group in
                Section("\(group.first?.title ?? "Duplicate") • \(group.count) copies") {
                    ForEach(group) { track in
                        HStack { SongRow(track: track, isCurrent: player.currentTrack?.id == track.id, isPlaying: player.isPlaying); Spacer(); Button(role: .destructive) { library.delete(track) } label: { Image(systemName: "trash") } }
                    }
                }
            }
        }.navigationTitle("Duplicates")
    }
}

private struct MissingFilesView: View {
    @ObservedObject var library: MusicLibrary
    var body: some View {
        List(library.missingFiles) { track in VStack(alignment: .leading) { Text(track.title); Text(track.originalFileName).font(.caption).foregroundStyle(.secondary) } }.navigationTitle("Missing Files")
    }
}
