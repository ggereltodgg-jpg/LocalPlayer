import SwiftUI

struct TrackActionsView: View {
    let track: Track
    @ObservedObject var library: MusicLibrary
    @ObservedObject var playlists: PlaylistStore
    @ObservedObject var player: PlayerManager
    @State private var showEditor = false
    @State private var showLyrics = false

    var body: some View {
        Menu {
            Button { player.playNext(track) } label: { Label("Play Next", systemImage: "text.insert") }
            Button { player.playLater(track) } label: { Label("Play Later", systemImage: "text.append") }
            Button { library.toggleFavorite(track) } label: { Label(track.isFavorite ? "Unfavorite" : "Favorite", systemImage: track.isFavorite ? "heart.slash" : "heart") }
            Menu("Rating") {
                Button("Clear") { library.setRating(track, rating: 0) }
                ForEach(1...5, id: \.self) { n in Button(String(repeating: "★", count: n)) { library.setRating(track, rating: n) } }
            }
            Menu("Add to Playlist") {
                ForEach(playlists.playlists) { playlist in Button(playlist.name) { playlists.add(track.id, to: playlist.id) } }
            }
            Button { showLyrics = true } label: { Label("Lyrics", systemImage: "quote.bubble") }
            Button { showEditor = true } label: { Label("Edit Metadata", systemImage: "pencil") }
            Button { Task { await library.analyze(track) } } label: { Label("Analyze BPM / Key / Loudness", systemImage: "waveform.badge.magnifyingglass") }
            Button { Task { await library.rebuildArtwork(track) } } label: { Label("Recover Embedded Artwork", systemImage: "photo.badge.arrow.down") }
        } label: {
            Image(systemName: "ellipsis")
        }
        .sheet(isPresented: $showEditor) { MetadataEditorView(track: track, library: library) }
        .sheet(isPresented: $showLyrics) { LyricsView(track: track, library: library, player: player) }
    }
}
