import SwiftUI

@main
@MainActor
struct LocalRapPlayerApp: App {
    @StateObject private var library: MusicLibrary
    @StateObject private var playlists: PlaylistStore
    @StateObject private var settings: SettingsStore
    @StateObject private var player: PlayerManager
    @Environment(\.scenePhase) private var scenePhase

    init() {
        let lib = MusicLibrary()
        let pls = PlaylistStore()
        let set = SettingsStore()
        let p = PlayerManager()
        p.library = lib
        p.settings = set
        p.applySettings()
        _library = StateObject(wrappedValue: lib)
        _playlists = StateObject(wrappedValue: pls)
        _settings = StateObject(wrappedValue: set)
        _player = StateObject(wrappedValue: p)
    }

    var body: some Scene {
        WindowGroup {
            PrivacyGateView(settings: settings) {
                ContentView(library: library, playlists: playlists, player: player, settings: settings)
                    .tint(.pink)
                    .preferredColorScheme(colorScheme)
            }
        }
        .onChange(of: scenePhase) { _, phase in
            if phase != .active { library.flushStats() }
        }
    }

    private var colorScheme: ColorScheme? {
        switch settings.theme {
        case .system: return nil
        case .dark: return .dark
        case .light: return .light
        }
    }
}
