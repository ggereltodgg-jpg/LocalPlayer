import SwiftUI

struct SongRow: View {
    let track: Track
    let isCurrent: Bool
    let isPlaying: Bool

    var body: some View {
        HStack(spacing: 12) {
            ArtworkView(track: track, size: 50)
            VStack(alignment: .leading, spacing: 3) {
                Text(track.title).font(.body.weight(isCurrent ? .semibold : .regular)).lineLimit(1)
                Text(track.artist).font(.subheadline).foregroundStyle(.secondary).lineLimit(1)
                HStack(spacing: 8) {
                    if let bpm = track.bpm { Text("\(Int(bpm.rounded())) BPM") }
                    if let key = track.musicalKey { Text(key) }
                    if track.rating > 0 { Text(String(repeating: "★", count: track.rating)) }
                }.font(.caption2).foregroundStyle(.tertiary)
            }
            Spacer()
            if isCurrent { Image(systemName: isPlaying ? "waveform" : "pause.fill").foregroundStyle(.tint) }
        }
        .contentShape(Rectangle())
    }
}
