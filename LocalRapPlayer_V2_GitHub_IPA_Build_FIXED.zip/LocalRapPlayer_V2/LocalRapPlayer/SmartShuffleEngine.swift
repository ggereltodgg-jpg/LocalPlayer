import Foundation

struct SmartShuffleEngine {
    static func makeQueue(from tracks: [Track], artistGap: Int) -> [Track] {
        guard tracks.count > 2 else { return tracks.shuffled() }
        var remaining = tracks.shuffled()
        var result: [Track] = []
        let gap = max(1, artistGap)

        while !remaining.isEmpty {
            let recentArtists = Set(result.suffix(gap).map { normalizedArtist($0.artist) })
            if let index = remaining.firstIndex(where: { !recentArtists.contains(normalizedArtist($0.artist)) }) {
                result.append(remaining.remove(at: index))
            } else {
                result.append(remaining.removeFirst())
            }
        }
        return result
    }

    private static func normalizedArtist(_ value: String) -> String {
        value.lowercased().trimmingCharacters(in: .whitespacesAndNewlines)
    }
}
