import SwiftUI

struct QueueView: View {
    @ObservedObject var player: PlayerManager
    @Environment(\.dismiss) private var dismiss

    var body: some View {
        NavigationStack {
            List {
                Section("Queue") {
                    ForEach(Array(player.queue.enumerated()), id: \.element.id) { index, track in
                        HStack {
                            ArtworkView(track: track, size: 42)
                            VStack(alignment: .leading) {
                                Text(track.title).lineLimit(1).fontWeight(index == player.currentIndex ? .semibold : .regular)
                                Text(track.artist).font(.caption).foregroundStyle(.secondary).lineLimit(1)
                            }
                            Spacer()
                            if index == player.currentIndex { Image(systemName: player.isPlaying ? "waveform" : "pause.fill").foregroundStyle(.tint) }
                            Image(systemName: "line.3.horizontal").foregroundStyle(.secondary)
                        }
                        .contentShape(Rectangle())
                        .onTapGesture { player.replaceQueue(player.queue, startIndex: index) }
                    }
                    .onDelete(perform: player.removeFromQueue)
                    .onMove(perform: player.moveQueue)
                }
            }
            .environment(\.editMode, .constant(.active))
            .navigationTitle("Queue")
            .toolbar { ToolbarItem(placement: .topBarLeading) { Button("Done") { dismiss() } } }
        }
    }
}
