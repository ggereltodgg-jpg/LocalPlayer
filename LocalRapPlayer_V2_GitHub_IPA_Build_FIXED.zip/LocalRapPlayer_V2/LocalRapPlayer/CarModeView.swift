import SwiftUI

struct CarModeView: View {
    @ObservedObject var player: PlayerManager
    @Environment(\.dismiss) private var dismiss

    var body: some View {
        NavigationStack {
            VStack(spacing: 28) {
                Spacer()
                if let track = player.currentTrack {
                    ArtworkView(track: track, size: 260)
                    Text(track.title).font(.largeTitle.bold()).lineLimit(1)
                    Text(track.artist).font(.title2).foregroundStyle(.secondary).lineLimit(1)
                    HStack(spacing: 50) {
                        Button(action: player.previous) { Image(systemName: "backward.fill").font(.system(size: 42)) }
                        Button(action: player.togglePlayPause) { Image(systemName: player.isPlaying ? "pause.circle.fill" : "play.circle.fill").font(.system(size: 92)) }
                        Button { player.next() } label: { Image(systemName: "forward.fill").font(.system(size: 42)) }
                    }
                } else {
                    ContentUnavailableView("Nothing Playing", systemImage: "car.fill")
                }
                Spacer()
            }
            .padding()
            .navigationTitle("Car Mode")
            .toolbar { ToolbarItem(placement: .topBarLeading) { Button("Done") { dismiss() } } }
        }
    }
}
