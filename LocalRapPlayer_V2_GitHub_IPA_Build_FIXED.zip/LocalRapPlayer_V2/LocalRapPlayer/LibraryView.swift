import SwiftUI
import UniformTypeIdentifiers
import MediaPlayer

struct LibraryView: View {
    @ObservedObject var library: MusicLibrary
    @ObservedObject var playlists: PlaylistStore
    @ObservedObject var player: PlayerManager
    @ObservedObject var settings: SettingsStore
    @State private var searchText = ""
    @State private var showFilesImporter = false
    @State private var showFolderImporter = false
    @State private var showPlaylistImporter = false

    private var filteredTracks: [Track] {
        guard !searchText.isEmpty else { return library.tracks }
        return library.tracks.filter {
            $0.title.localizedCaseInsensitiveContains(searchText) || $0.artist.localizedCaseInsensitiveContains(searchText) || $0.album.localizedCaseInsensitiveContains(searchText)
        }
    }

    var body: some View {
        NavigationStack {
            Group {
                if library.tracks.isEmpty {
                    ContentUnavailableView {
                        Label("No Music Yet", systemImage: "music.note.list")
                    } description: {
                        Text("Import M4A, MP3, AAC, FLAC or a whole folder from Files.")
                    } actions: {
                        VStack(spacing: 10) {
                            Button("Use iPhone Music Library") { Task { await library.requestAndSyncIPhoneMusic() } }
                                .buttonStyle(.borderedProminent)
                            Button("Import Music Files") { showFilesImporter = true }
                                .buttonStyle(.bordered)
                        }
                    }
                } else {
                    List {
                        if library.isImporting || !library.importStatus.isEmpty || !library.analysisProgress.isEmpty {
                            Section {
                                if library.isImporting { HStack { ProgressView(); Text(library.importStatus).font(.footnote).foregroundStyle(.secondary) } }
                                if !library.analysisProgress.isEmpty { Text(library.analysisProgress).font(.footnote).foregroundStyle(.secondary) }
                            }
                        }

                        Section("iTunes / iPhone Music") {
                            Button { Task { await library.requestAndSyncIPhoneMusic() } } label: {
                                Label(library.mediaLibraryAuthorization == .authorized ? "Sync iPhone Music" : "Connect iPhone Music", systemImage: "music.note.house.fill")
                            }
                            HStack {
                                Text(library.mediaLibraryStatusText)
                                Spacer()
                                if library.mediaLibraryTrackCount > 0 { Text("\(library.mediaLibraryTrackCount)").foregroundStyle(.secondary) }
                            }.font(.footnote)
                            if library.mediaLibraryTrackCount > 0 {
                                Button("Restore Hidden Synced Songs") { Task { await library.restoreHiddenIPhoneMusic() } }
                                    .font(.footnote)
                            }
                        }

                        Section {
                            Button { player.playQueue(filteredTracks, smartShuffle: true) } label: { Label("Smart Shuffle", systemImage: "shuffle.circle.fill") }
                            NavigationLink { ArtistsView(library: library, playlists: playlists, player: player) } label: { Label("Artists", systemImage: "person.2.fill") }
                            NavigationLink { AlbumsView(library: library, playlists: playlists, player: player) } label: { Label("Albums", systemImage: "square.stack.fill") }
                            NavigationLink { FolderView(library: library, playlists: playlists, player: player) } label: { Label("Folders", systemImage: "folder.fill") }
                            NavigationLink { StatsView(library: library) } label: { Label("Listening Stats", systemImage: "chart.bar.xaxis") }
                        }

                        Section("\(filteredTracks.count) Songs") {
                            ForEach(filteredTracks) { track in
                                HStack {
                                    SongRow(track: track, isCurrent: player.currentTrack?.id == track.id, isPlaying: player.isPlaying)
                                        .onTapGesture { player.play(track, in: filteredTracks) }
                                    TrackActionsView(track: track, library: library, playlists: playlists, player: player)
                                }
                                .swipeActions(edge: .leading) {
                                    Button { library.toggleFavorite(track) } label: { Label("Favorite", systemImage: "heart") }.tint(.pink)
                                }
                                .swipeActions(edge: .trailing) {
                                    Button(role: .destructive) { library.delete(track) } label: { Label(track.sourceKind == .mediaLibrary ? "Hide" : "Delete", systemImage: "trash") }
                                }
                            }
                        }
                    }.listStyle(.plain)
                }
            }
            .navigationTitle("My Music")
            .searchable(text: $searchText, prompt: "Songs, artists, albums")
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) {
                    Menu {
                        Button("Import Audio Files", systemImage: "music.note") { showFilesImporter = true }
                        Button("Import Folder", systemImage: "folder") { showFolderImporter = true }
                        Button("Sync iTunes Music from iPhone", systemImage: "music.note.house") { Task { await library.requestAndSyncIPhoneMusic() } }
                        Button("Import iTunes / M3U Playlist", systemImage: "text.badge.plus") { showPlaylistImporter = true }
                    } label: { Image(systemName: "plus.circle.fill") }
                }
            }
            .safeAreaInset(edge: .bottom) { MiniPlayerView(player: player) }
            .fileImporter(isPresented: $showFilesImporter, allowedContentTypes: [.audio], allowsMultipleSelection: true) { result in
                if case .success(let urls) = result { Task { await library.importFiles(urls) } }
            }
            .fileImporter(isPresented: $showFolderImporter, allowedContentTypes: [.folder], allowsMultipleSelection: false) { result in
                if case .success(let urls) = result, let folder = urls.first { Task { await library.importFolder(folder) } }
            }
            .fileImporter(isPresented: $showPlaylistImporter, allowedContentTypes: [.xml, .plainText], allowsMultipleSelection: false) { result in
                if case .success(let urls) = result, let url = urls.first { library.importPlaylistFile(url, playlistStore: playlists) }
            }
        }
    }
}
