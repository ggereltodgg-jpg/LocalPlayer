import SwiftUI
import UniformTypeIdentifiers
import UIKit

struct SettingsView: View {
    @ObservedObject var library: MusicLibrary
    @ObservedObject var playlists: PlaylistStore
    @ObservedObject var player: PlayerManager
    @ObservedObject var settings: SettingsStore
    @State private var backupURL: URL?
    @State private var showRestore = false
    @State private var showCarMode = false

    var body: some View {
        NavigationStack {
            Form {
                Section("Playback") {
                    HStack { Text("Crossfade"); Slider(value: $settings.crossfadeSeconds, in: 0...10, step: 1); Text("\(Int(settings.crossfadeSeconds))s").monospacedDigit().frame(width: 28) }
                    Toggle("Gapless Playback", isOn: $settings.gaplessEnabled)
                    Toggle("Normalize Volume", isOn: $settings.normalizeVolume)
                    Picker("EQ", selection: $settings.eqPreset) { ForEach(SettingsStore.EQPreset.allCases) { Text($0.title).tag($0) } }
                        .onChange(of: settings.eqPreset) { _, preset in player.applyEQPreset(preset) }
                    Stepper("Smart Shuffle artist gap: \(settings.smartShuffleArtistGap)", value: $settings.smartShuffleArtistGap, in: 2...20)
                }

                Section("Sleep Timer") {
                    HStack {
                        ForEach([15, 30, 45, 60], id: \.self) { min in Button("\(min)m") { player.setSleepTimer(minutes: min) }.buttonStyle(.bordered) }
                    }
                    if let end = player.sleepTimerEnd { LabeledContent("Stops at", value: end.formatted(date: .omitted, time: .shortened)) }
                    Button("Cancel Sleep Timer", role: .destructive) { player.setSleepTimer(minutes: nil) }
                }

                Section("Appearance") {
                    Picker("Theme", selection: $settings.theme) { ForEach(SettingsStore.Theme.allCases) { Text($0.title).tag($0) } }
                    Toggle("Use Album Colors", isOn: $settings.useAlbumColors)
                    Button("Switch App Icon") { tryAlternateIcon() }
                }

                Section("Privacy & Car") {
                    Toggle("Face ID / Touch ID Lock", isOn: $settings.faceIDLockEnabled)
                    Button("Open Car Mode") { showCarMode = true }
                    NavigationLink("Library Tools") { DiagnosticsView(library: library, playlists: playlists, player: player) }
                }

                Section("Backup") {
                    Button("Create Playlist / Stats Backup") { backupURL = library.makeBackup(playlists: playlists.playlists) }
                    if let backupURL { ShareLink(item: backupURL) { Label("Share Backup", systemImage: "square.and.arrow.up") } }
                    Button("Restore Backup") { showRestore = true }
                    Text("Audio files are not duplicated into the backup; re-import your music first, then restore favorites, stats and playlists.").font(.footnote).foregroundStyle(.secondary)
                }

                Section("System Integration") {
                    Label("Lock Screen & Control Center: enabled", systemImage: "lock.iphone")
                    Label("Bluetooth / AirPlay: enabled", systemImage: "airplayaudio")
                    Label("Dynamic Island uses iOS Now Playing", systemImage: "capsule")
                    Text("Home Screen widgets and full CarPlay need extra Xcode targets/entitlements. Templates are included in the package.").font(.footnote).foregroundStyle(.secondary)
                }
            }
            .navigationTitle("Settings")
            .onChange(of: settings.normalizeVolume) { _, _ in player.applySettings() }
            .sheet(isPresented: $showCarMode) { CarModeView(player: player) }
            .fileImporter(isPresented: $showRestore, allowedContentTypes: [.json], allowsMultipleSelection: false) { result in
                if case .success(let urls) = result, let url = urls.first { library.restoreBackup(url, playlistStore: playlists) }
            }
        }
    }

    private func tryAlternateIcon() {
        guard UIApplication.shared.supportsAlternateIcons else { return }
        let current = UIApplication.shared.alternateIconName
        let next = current == "RapIcon" ? nil : "RapIcon"
        UIApplication.shared.setAlternateIconName(next)
    }
}
