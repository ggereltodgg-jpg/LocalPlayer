import SwiftUI

struct PlaylistsView: View {
    @ObservedObject var library: MusicLibrary
    @ObservedObject var playlists: PlaylistStore
    @ObservedObject var player: PlayerManager
    @State private var newName = ""
    @State private var showCreate = false

    var body: some View {
        NavigationStack {
            List {
                NavigationLink {
                    TrackCollectionView(title: "Favorites", subtitle: "\(library.favorites.count) songs", tracks: library.favorites, library: library, playlists: playlists, player: player)
                } label: { Label("Favorites", systemImage: "heart.fill") }

                ForEach(playlists.playlists) { playlist in
                    let tracks = playlist.trackIDs.compactMap { id in library.tracks.first(where: { $0.id == id }) }
                    NavigationLink {
                        PlaylistDetailView(playlist: playlist, library: library, playlists: playlists, player: player)
                    } label: {
                        HStack {
                            Image(systemName: "music.note.list").frame(width: 36, height: 36).background(.quaternary).clipShape(RoundedRectangle(cornerRadius: 8))
                            VStack(alignment: .leading) { Text(playlist.name); Text("\(tracks.count) songs").font(.caption).foregroundStyle(.secondary) }
                        }
                    }
                }
                .onDelete { offsets in
                    for i in offsets.sorted(by: >) { playlists.delete(playlists.playlists[i]) }
                }
            }
            .navigationTitle("Playlists")
            .toolbar { ToolbarItem(placement: .topBarTrailing) { Button { showCreate = true } label: { Image(systemName: "plus") } } }
            .alert("New Playlist", isPresented: $showCreate) {
                TextField("Playlist name", text: $newName)
                Button("Create") { playlists.create(name: newName); newName = "" }
                Button("Cancel", role: .cancel) { }
            }
            .safeAreaInset(edge: .bottom) { MiniPlayerView(player: player) }
        }
    }
}
