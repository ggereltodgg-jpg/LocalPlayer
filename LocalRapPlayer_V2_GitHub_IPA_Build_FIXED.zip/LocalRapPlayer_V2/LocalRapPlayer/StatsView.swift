import SwiftUI

struct StatsView: View {
    @ObservedObject var library: MusicLibrary

    private var totalHours: Double { library.tracks.reduce(0) { $0 + $1.totalListenSeconds } / 3600 }
    private var topArtists: [(String, Int)] {
        var counts: [String: Int] = [:]
        for track in library.tracks { counts[track.artist, default: 0] += max(0, track.playCount) }
        return counts.map { ($0.key, $0.value) }.sorted { $0.1 > $1.1 }.prefix(15).map { $0 }
    }

    var body: some View {
        List {
            Section("Overview") {
                LabeledContent("Songs", value: "\(library.tracks.count)")
                LabeledContent("Artists", value: "\(library.artists.count)")
                LabeledContent("Albums", value: "\(library.albums.count)")
                LabeledContent("Listening time", value: String(format: "%.1f h", totalHours))
            }
            Section("Top Songs") {
                ForEach(Array(library.mostPlayed.prefix(15).enumerated()), id: \.element.id) { index, track in
                    HStack { Text("\(index + 1)").foregroundStyle(.secondary).frame(width: 24); VStack(alignment: .leading) { Text(track.title); Text("\(track.artist) • \(track.playCount) plays").font(.caption).foregroundStyle(.secondary) } }
                }
            }
            Section("Top Artists") {
                ForEach(Array(topArtists.enumerated()), id: \.offset) { index, item in LabeledContent("\(index + 1). \(item.0)", value: "\(item.1) plays") }
            }
        }.navigationTitle("Stats")
    }
}
