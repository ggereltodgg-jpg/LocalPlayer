import Foundation

@MainActor
final class SettingsStore: ObservableObject {
    enum Theme: String, CaseIterable, Identifiable {
        case system, dark, light
        var id: String { rawValue }
        var title: String { rawValue.capitalized }
    }

    enum EQPreset: String, CaseIterable, Identifiable {
        case flat, rap, bassBoost, vocal, rnb, car
        var id: String { rawValue }
        var title: String {
            switch self {
            case .flat: return "Flat"
            case .rap: return "Rap"
            case .bassBoost: return "Bass Boost"
            case .vocal: return "Vocal"
            case .rnb: return "R&B"
            case .car: return "Car"
            }
        }
    }

    @Published var crossfadeSeconds: Double { didSet { save() } }
    @Published var normalizeVolume: Bool { didSet { save() } }
    @Published var eqPreset: EQPreset { didSet { save() } }
    @Published var theme: Theme { didSet { save() } }
    @Published var useAlbumColors: Bool { didSet { save() } }
    @Published var smartShuffleArtistGap: Int { didSet { save() } }
    @Published var faceIDLockEnabled: Bool { didSet { save() } }
    @Published var carModeLargeControls: Bool { didSet { save() } }
    @Published var gaplessEnabled: Bool { didSet { save() } }

    private let defaults = UserDefaults.standard

    init() {
        crossfadeSeconds = defaults.object(forKey: "crossfadeSeconds") as? Double ?? 5
        normalizeVolume = defaults.object(forKey: "normalizeVolume") as? Bool ?? true
        eqPreset = EQPreset(rawValue: defaults.string(forKey: "eqPreset") ?? "rap") ?? .rap
        theme = Theme(rawValue: defaults.string(forKey: "theme") ?? "dark") ?? .dark
        useAlbumColors = defaults.object(forKey: "useAlbumColors") as? Bool ?? true
        smartShuffleArtistGap = defaults.object(forKey: "smartShuffleArtistGap") as? Int ?? 8
        faceIDLockEnabled = defaults.object(forKey: "faceIDLockEnabled") as? Bool ?? false
        carModeLargeControls = defaults.object(forKey: "carModeLargeControls") as? Bool ?? false
        gaplessEnabled = defaults.object(forKey: "gaplessEnabled") as? Bool ?? true
    }

    private func save() {
        defaults.set(crossfadeSeconds, forKey: "crossfadeSeconds")
        defaults.set(normalizeVolume, forKey: "normalizeVolume")
        defaults.set(eqPreset.rawValue, forKey: "eqPreset")
        defaults.set(theme.rawValue, forKey: "theme")
        defaults.set(useAlbumColors, forKey: "useAlbumColors")
        defaults.set(smartShuffleArtistGap, forKey: "smartShuffleArtistGap")
        defaults.set(faceIDLockEnabled, forKey: "faceIDLockEnabled")
        defaults.set(carModeLargeControls, forKey: "carModeLargeControls")
        defaults.set(gaplessEnabled, forKey: "gaplessEnabled")
    }
}
