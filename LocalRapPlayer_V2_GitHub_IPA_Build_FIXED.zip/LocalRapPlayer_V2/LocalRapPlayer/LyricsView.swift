import SwiftUI
import UniformTypeIdentifiers

struct LyricsView: View {
    let track: Track
    @ObservedObject var library: MusicLibrary
    @ObservedObject var player: PlayerManager
    @Environment(\.dismiss) private var dismiss
    @State private var showImporter = false

    private var liveTrack: Track { library.tracks.first(where: { $0.id == track.id }) ?? track }
    private var lyricsText: String? { library.lyricsText(for: liveTrack) }
    private var lines: [LyricLine] { lyricsText.map(LRCParser.parse) ?? [] }
    private var activeIndex: Int? {
        guard !lines.isEmpty else { return nil }
        return lines.lastIndex(where: { $0.time <= player.elapsed })
    }

    var body: some View {
        NavigationStack {
            ScrollViewReader { proxy in
                ScrollView {
                    if let text = lyricsText {
                        if lines.isEmpty {
                            Text(text).font(.title3).padding().frame(maxWidth: .infinity, alignment: .leading)
                        } else {
                            LazyVStack(alignment: .leading, spacing: 18) {
                                ForEach(Array(lines.enumerated()), id: \.element.id) { index, line in
                                    Text(line.text.isEmpty ? "♪" : line.text)
                                        .font(index == activeIndex ? .title2.bold() : .title3)
                                        .foregroundStyle(index == activeIndex ? .primary : .secondary)
                                        .id(index)
                                        .onTapGesture { player.seek(to: line.time) }
                                }
                            }.padding()
                        }
                    } else {
                        ContentUnavailableView("No Lyrics", systemImage: "quote.bubble", description: Text("Import an .lrc or .txt lyric file for this song."))
                            .padding(.top, 80)
                    }
                }
                .onChange(of: activeIndex) { _, newValue in
                    if let newValue { withAnimation { proxy.scrollTo(newValue, anchor: .center) } }
                }
            }
            .navigationTitle("Lyrics")
            .toolbar {
                ToolbarItem(placement: .topBarLeading) { Button("Done") { dismiss() } }
                ToolbarItem(placement: .topBarTrailing) { Button("Import") { showImporter = true } }
            }
            .fileImporter(isPresented: $showImporter, allowedContentTypes: [.plainText], allowsMultipleSelection: false) { result in
                if case .success(let urls) = result, let url = urls.first { library.attachLyrics(url, to: track.id) }
            }
        }
    }
}
