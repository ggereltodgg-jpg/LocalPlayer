import Foundation
import SwiftUI
import AVFoundation
import MediaPlayer
import UIKit

@MainActor
final class PlayerManager: ObservableObject {
    enum RepeatMode: String, CaseIterable { case off, all, one }

    @Published private(set) var currentTrack: Track?
    @Published private(set) var isPlaying = false
    @Published private(set) var elapsed: Double = 0
    @Published private(set) var duration: Double = 0
    @Published private(set) var queue: [Track] = []
    @Published private(set) var currentIndex: Int = 0
    @Published var shuffleEnabled = false
    @Published var repeatMode: RepeatMode = .off
    @Published private(set) var sleepTimerEnd: Date?

    weak var library: MusicLibrary?
    var settings: SettingsStore?

    private let engine = AVAudioEngine()
    private let nodeA = AVAudioPlayerNode()
    private let nodeB = AVAudioPlayerNode()
    private let mixNode = AVAudioMixerNode()
    private let eq = AVAudioUnitEQ(numberOfBands: 10)
    private var activeIsA = true
    private var timer: Timer?
    private var isTransitioning = false
    private var sleepTask: Task<Void, Never>?
    private var lastTick = Date()

    private var activeNode: AVAudioPlayerNode { activeIsA ? nodeA : nodeB }
    private var inactiveNode: AVAudioPlayerNode { activeIsA ? nodeB : nodeA }

    init() {
        configureAudioSession()
        configureEngine()
        configureRemoteCommands()
        startTimer()
    }

    deinit {
        timer?.invalidate()
        sleepTask?.cancel()
    }

    func applySettings() {
        applyEQPreset(settings?.eqPreset ?? .rap)
        applyTrackVolume()
    }

    func play(_ track: Track, in tracks: [Track]) {
        queue = tracks
        currentIndex = tracks.firstIndex(where: { $0.id == track.id }) ?? 0
        startCurrent(at: 0)
    }

    func playQueue(_ tracks: [Track], shuffled: Bool = false, smartShuffle: Bool = false) {
        guard !tracks.isEmpty else { return }
        if smartShuffle {
            queue = SmartShuffleEngine.makeQueue(from: tracks, artistGap: settings?.smartShuffleArtistGap ?? 8)
        } else {
            queue = shuffled ? tracks.shuffled() : tracks
        }
        currentIndex = 0
        startCurrent(at: 0)
    }

    func replaceQueue(_ tracks: [Track], startIndex: Int = 0) {
        queue = tracks
        currentIndex = min(max(0, startIndex), max(0, tracks.count - 1))
        if !tracks.isEmpty { startCurrent(at: 0) }
    }

    func playNext(_ track: Track) {
        guard !queue.isEmpty else { queue = [track]; currentIndex = 0; startCurrent(at: 0); return }
        queue.removeAll { $0.id == track.id }
        queue.insert(track, at: min(currentIndex + 1, queue.count))
    }

    func playLater(_ track: Track) {
        queue.removeAll { $0.id == track.id }
        queue.append(track)
    }

    func removeFromQueue(at offsets: IndexSet) {
        let currentID = currentTrack?.id
        queue.remove(atOffsets: offsets)
        if let currentID, let idx = queue.firstIndex(where: { $0.id == currentID }) { currentIndex = idx }
    }

    func moveQueue(from offsets: IndexSet, to destination: Int) {
        let currentID = currentTrack?.id
        queue.move(fromOffsets: offsets, toOffset: destination)
        if let currentID, let idx = queue.firstIndex(where: { $0.id == currentID }) { currentIndex = idx }
    }

    func togglePlayPause() {
        if isPlaying {
            nodeA.pause(); nodeB.pause(); isPlaying = false
        } else {
            if !engine.isRunning { try? engine.start() }
            activeNode.play(); isPlaying = true
        }
        updateNowPlaying()
    }

    func next(userInitiated: Bool = true) {
        guard !queue.isEmpty else { return }
        if userInitiated, let id = currentTrack?.id, elapsed < min(30, duration * 0.35) { library?.markSkipped(id) }
        if repeatMode == .one && !userInitiated { startCurrent(at: 0); return }
        let nextIndex = resolvedNextIndex()
        if nextIndex == nil { stop(); return }
        currentIndex = nextIndex!
        startCurrent(at: 0)
    }

    func previous() {
        if elapsed > 4 { seek(to: 0); return }
        guard !queue.isEmpty else { return }
        currentIndex = max(0, currentIndex - 1)
        startCurrent(at: 0)
    }

    func seek(to seconds: Double) {
        guard currentTrack != nil else { return }
        startCurrent(at: max(0, min(seconds, duration)), countPlay: false)
    }

    func stop() {
        nodeA.stop(); nodeB.stop(); isPlaying = false; elapsed = 0
        updateNowPlaying()
    }

    func setSleepTimer(minutes: Int?) {
        sleepTask?.cancel()
        guard let minutes else { sleepTimerEnd = nil; return }
        let end = Date().addingTimeInterval(Double(minutes * 60))
        sleepTimerEnd = end
        sleepTask = Task { [weak self] in
            try? await Task.sleep(for: .seconds(Double(minutes * 60)))
            guard !Task.isCancelled else { return }
            await MainActor.run { self?.stop(); self?.sleepTimerEnd = nil }
        }
    }

    private func configureAudioSession() {
        do {
            try AVAudioSession.sharedInstance().setCategory(.playback, mode: .default, options: [.allowAirPlay, .allowBluetoothA2DP])
            try AVAudioSession.sharedInstance().setActive(true)
        } catch { print("Audio session error: \(error)") }
    }

    private func configureEngine() {
        engine.attach(nodeA); engine.attach(nodeB); engine.attach(mixNode); engine.attach(eq)
        engine.connect(nodeA, to: mixNode, format: nil)
        engine.connect(nodeB, to: mixNode, format: nil)
        engine.connect(mixNode, to: eq, format: nil)
        engine.connect(eq, to: engine.mainMixerNode, format: nil)
        applyEQPreset(.rap)
        engine.prepare()
        try? engine.start()
    }

    private func startCurrent(at seconds: Double, countPlay: Bool = true) {
        guard queue.indices.contains(currentIndex) else { return }
        isTransitioning = false
        nodeA.stop(); nodeB.stop()
        let track = queue[currentIndex]
        activeIsA = true
        currentTrack = track
        duration = max(track.duration, 0)
        elapsed = seconds
        guard schedule(track: track, on: activeNode, startAt: seconds) else {
            isPlaying = false
            updateNowPlaying()
            return
        }
        activeNode.volume = normalizedVolume(for: track)
        inactiveNode.volume = 0
        activeNode.play()
        isPlaying = true
        if countPlay { library?.markPlayed(track.id) }
        lastTick = Date()
        updateNowPlaying()
    }

    @discardableResult
    private func schedule(track: Track, on node: AVAudioPlayerNode, startAt seconds: Double) -> Bool {
        guard let url = MediaLibrarySupport.audioURL(for: track),
              let file = try? AVAudioFile(forReading: url) else { return false }
        let sr = file.processingFormat.sampleRate
        let startFrame = min(file.length, max(0, AVAudioFramePosition(seconds * sr)))
        let frames = file.length - startFrame
        guard frames > 0 else { return false }
        node.scheduleSegment(file, startingFrame: startFrame, frameCount: AVAudioFrameCount(min(frames, AVAudioFramePosition(UInt32.max))), at: nil, completionCallbackType: .dataPlayedBack) { [weak self] _ in
            Task { @MainActor in
                guard let self, !self.isTransitioning, self.currentTrack?.id == track.id else { return }
                self.handleTrackEnded()
            }
        }
        return true
    }

    private func handleTrackEnded() {
        if repeatMode == .one { startCurrent(at: 0); return }
        next(userInitiated: false)
    }

    private func resolvedNextIndex() -> Int? {
        guard !queue.isEmpty else { return nil }
        if shuffleEnabled, queue.count > 1 {
            let options = queue.indices.filter { $0 != currentIndex }
            return options.randomElement()
        }
        if currentIndex + 1 < queue.count { return currentIndex + 1 }
        return repeatMode == .all ? 0 : nil
    }

    private func startTimer() {
        timer = Timer.scheduledTimer(withTimeInterval: 0.25, repeats: true) { [weak self] _ in
            Task { @MainActor in self?.tick() }
        }
        RunLoop.main.add(timer!, forMode: .common)
    }

    private func tick() {
        let now = Date(); defer { lastTick = now }
        guard isPlaying, currentTrack != nil else { return }
        let delta = min(1, now.timeIntervalSince(lastTick))
        elapsed += delta
        if let id = currentTrack?.id { library?.addListenTime(id, seconds: delta) }
        if Int(elapsed * 2) % 10 == 0 { updateNowPlaying() }

        let remaining = duration - elapsed
        let crossfade = settings?.crossfadeSeconds ?? 0
        if crossfade > 0, remaining > 0, remaining <= crossfade, !isTransitioning, repeatMode != .one {
            beginCrossfade(seconds: min(crossfade, max(0.5, remaining)))
        } else if remaining <= 0.05, !isTransitioning {
            handleTrackEnded()
        }
    }

    private func beginCrossfade(seconds: Double) {
        guard let nextIndex = resolvedNextIndex(), queue.indices.contains(nextIndex), let current = currentTrack else { return }
        isTransitioning = true
        let oldNode = activeNode
        let newNode = inactiveNode
        let nextTrack = queue[nextIndex]
        newNode.stop()
        guard schedule(track: nextTrack, on: newNode, startAt: 0) else {
            isTransitioning = false
            return
        }
        let newBase = normalizedVolume(for: nextTrack)
        let oldBase = normalizedVolume(for: current)
        newNode.volume = 0
        newNode.play()

        currentIndex = nextIndex
        currentTrack = nextTrack
        duration = max(nextTrack.duration, 0)
        elapsed = 0
        library?.markPlayed(nextTrack.id)
        updateNowPlaying()

        Task { [weak self] in
            guard let self else { return }
            let steps = max(8, Int(seconds / 0.05))
            for step in 0...steps {
                let progress = Float(step) / Float(steps)
                oldNode.volume = oldBase * (1 - progress)
                newNode.volume = newBase * progress
                try? await Task.sleep(for: .seconds(seconds / Double(steps)))
            }
            oldNode.stop()
            oldNode.volume = 0
            self.activeIsA.toggle()
            self.isTransitioning = false
            self.lastTick = Date()
        }
    }

    private func normalizedVolume(for track: Track) -> Float {
        guard settings?.normalizeVolume == true, let db = track.replayGainDB else { return 1 }
        return Float(min(1.5, max(0.25, pow(10.0, db / 20.0))))
    }

    private func applyTrackVolume() {
        guard let track = currentTrack else { return }
        activeNode.volume = normalizedVolume(for: track)
    }

    func applyEQPreset(_ preset: SettingsStore.EQPreset) {
        let freqs: [Float] = [32, 64, 125, 250, 500, 1000, 2000, 4000, 8000, 16000]
        let gains: [Float]
        switch preset {
        case .flat: gains = Array(repeating: 0, count: 10)
        case .rap: gains = [3.5, 4.5, 3.0, 0.5, -1, 0, 1, 1.5, 2, 1]
        case .bassBoost: gains = [6, 6, 4.5, 2, 0, 0, 0, 0, 0.5, 1]
        case .vocal: gains = [-1, -1, 0, 1, 2, 3, 3.5, 2, 1, 0]
        case .rnb: gains = [2.5, 3.5, 2.5, 0, -0.5, 1, 2, 2.5, 2, 1]
        case .car: gains = [4, 4, 2.5, 0, -1, 0.5, 2, 2, 1, 0]
        }
        for i in 0..<eq.bands.count {
            eq.bands[i].filterType = .parametric
            eq.bands[i].frequency = freqs[i]
            eq.bands[i].bandwidth = 1
            eq.bands[i].gain = gains[i]
            eq.bands[i].bypass = false
        }
        eq.globalGain = 0
    }

    private func configureRemoteCommands() {
        let center = MPRemoteCommandCenter.shared()
        center.playCommand.addTarget { [weak self] _ in Task { @MainActor in if self?.isPlaying == false { self?.togglePlayPause() } }; return .success }
        center.pauseCommand.addTarget { [weak self] _ in Task { @MainActor in if self?.isPlaying == true { self?.togglePlayPause() } }; return .success }
        center.nextTrackCommand.addTarget { [weak self] _ in Task { @MainActor in self?.next() }; return .success }
        center.previousTrackCommand.addTarget { [weak self] _ in Task { @MainActor in self?.previous() }; return .success }
        center.changePlaybackPositionCommand.addTarget { [weak self] event in
            guard let event = event as? MPChangePlaybackPositionCommandEvent else { return .commandFailed }
            Task { @MainActor in self?.seek(to: event.positionTime) }
            return .success
        }
    }

    private func updateNowPlaying() {
        guard let track = currentTrack else { MPNowPlayingInfoCenter.default().nowPlayingInfo = nil; return }
        var info: [String: Any] = [
            MPMediaItemPropertyTitle: track.title,
            MPMediaItemPropertyArtist: track.artist,
            MPMediaItemPropertyAlbumTitle: track.album,
            MPMediaItemPropertyPlaybackDuration: duration,
            MPNowPlayingInfoPropertyElapsedPlaybackTime: elapsed,
            MPNowPlayingInfoPropertyPlaybackRate: isPlaying ? 1.0 : 0.0
        ]
        if let artURL = AppPaths.artworkURL(for: track), let data = try? Data(contentsOf: artURL), let image = UIImage(data: data) {
            info[MPMediaItemPropertyArtwork] = MPMediaItemArtwork(boundsSize: image.size) { _ in image }
        }
        MPNowPlayingInfoCenter.default().nowPlayingInfo = info
    }
}
