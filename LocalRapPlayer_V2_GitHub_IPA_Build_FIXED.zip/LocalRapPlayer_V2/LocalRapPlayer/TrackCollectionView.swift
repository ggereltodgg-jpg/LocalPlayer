import SwiftUI

struct TrackCollectionView: View {
    let title: String
    let subtitle: String
    let tracks: [Track]
    @ObservedObject var library: MusicLibrary
    @ObservedObject var playlists: PlaylistStore
    @ObservedObject var player: PlayerManager

    var body: some View {
        List {
            Section {
                HStack {
                    Button { player.playQueue(tracks) } label: { Label("Play", systemImage: "play.fill") }.buttonStyle(.borderedProminent)
                    Button { player.playQueue(tracks, smartShuffle: true) } label: { Label("Shuffle", systemImage: "shuffle") }.buttonStyle(.bordered)
                }
            }
            ForEach(tracks) { track in
                HStack {
                    SongRow(track: track, isCurrent: player.currentTrack?.id == track.id, isPlaying: player.isPlaying).onTapGesture { player.play(track, in: tracks) }
                    TrackActionsView(track: track, library: library, playlists: playlists, player: player)
                }
            }
        }
        .navigationTitle(title)
        .navigationBarTitleDisplayMode(.large)
        .safeAreaInset(edge: .bottom) { MiniPlayerView(player: player) }
    }
}
