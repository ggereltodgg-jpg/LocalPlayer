import Foundation

struct TrackBackup: Codable {
    var originalFileName: String
    var title: String
    var artist: String
    var album: String
    var isFavorite: Bool
    var rating: Int
    var playCount: Int
    var skipCount: Int
    var totalListenSeconds: Double
    var bpm: Double?
    var musicalKey: String?
    var replayGainDB: Double?
}

struct PlaylistBackup: Codable {
    var name: String
    var originalFileNames: [String]
}

struct LibraryBackup: Codable {
    var createdAt: Date
    var tracks: [TrackBackup]
    var playlists: [PlaylistBackup]
}
