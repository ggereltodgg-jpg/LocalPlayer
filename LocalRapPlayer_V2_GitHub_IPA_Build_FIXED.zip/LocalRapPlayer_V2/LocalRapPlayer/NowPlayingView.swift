import SwiftUI

struct NowPlayingView: View {
    @ObservedObject var player: PlayerManager
    @Environment(\.dismiss) private var dismiss
    @State private var showQueue = false
    @State private var showLyrics = false

    var body: some View {
        NavigationStack {
            VStack(spacing: 24) {
                Spacer(minLength: 8)
                if let track = player.currentTrack {
                    ArtworkView(track: track, size: 300).shadow(radius: 20, y: 10)
                    VStack(spacing: 5) {
                        Text(track.title).font(.title2.bold()).lineLimit(2).multilineTextAlignment(.center)
                        Text(track.artist).font(.title3).foregroundStyle(.secondary)
                        if !track.album.isEmpty { Text(track.album).font(.subheadline).foregroundStyle(.tertiary).lineLimit(1) }
                        HStack(spacing: 8) {
                            if let bpm = track.bpm { Text("\(Int(bpm.rounded())) BPM") }
                            if let key = track.musicalKey { Text(key) }
                        }.font(.caption).foregroundStyle(.secondary)
                    }.padding(.horizontal)

                    VStack(spacing: 8) {
                        Slider(value: Binding(get: { player.elapsed }, set: { player.seek(to: $0) }), in: 0...max(player.duration, 1))
                        HStack { Text(time(player.elapsed)); Spacer(); Text("-\(time(max(0, player.duration - player.elapsed)))") }.font(.caption.monospacedDigit()).foregroundStyle(.secondary)
                    }.padding(.horizontal, 20)

                    HStack(spacing: 38) {
                        Button(action: player.previous) { Image(systemName: "backward.fill").font(.title) }
                        Button(action: player.togglePlayPause) { Image(systemName: player.isPlaying ? "pause.circle.fill" : "play.circle.fill").font(.system(size: 72)) }
                        Button { player.next() } label: { Image(systemName: "forward.fill").font(.title) }
                    }

                    HStack(spacing: 34) {
                        Button { player.shuffleEnabled.toggle() } label: { Image(systemName: "shuffle").foregroundStyle(player.shuffleEnabled ? Color.accentColor : Color.secondary) }
                        Button {
                            player.repeatMode = player.repeatMode == .off ? .all : (player.repeatMode == .all ? .one : .off)
                        } label: {
                            Image(systemName: player.repeatMode == .one ? "repeat.1" : "repeat").foregroundStyle(player.repeatMode == .off ? Color.secondary : Color.accentColor)
                        }
                        Button { showLyrics = true } label: { Image(systemName: "quote.bubble") }
                        Button { showQueue = true } label: { Image(systemName: "list.bullet") }
                    }.font(.title3)
                }
                Spacer()
            }
            .padding(.horizontal)
            .toolbar { ToolbarItem(placement: .topBarLeading) { Button("Done") { dismiss() } } }
            .sheet(isPresented: $showQueue) { QueueView(player: player) }
            .sheet(isPresented: $showLyrics) {
                if let track = player.currentTrack, let library = player.library { LyricsView(track: track, library: library, player: player) }
            }
        }.presentationDetents([.large])
    }

    private func time(_ seconds: Double) -> String {
        guard seconds.isFinite else { return "0:00" }
        let total = max(0, Int(seconds.rounded()))
        return String(format: "%d:%02d", total / 60, total % 60)
    }
}
