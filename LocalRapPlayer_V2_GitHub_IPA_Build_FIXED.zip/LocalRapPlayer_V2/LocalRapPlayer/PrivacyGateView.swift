import SwiftUI
import LocalAuthentication

struct PrivacyGateView<Content: View>: View {
    @ObservedObject var settings: SettingsStore
    let content: () -> Content
    @Environment(\.scenePhase) private var scenePhase
    @State private var unlocked = false
    @State private var errorText = ""

    var body: some View {
        Group {
            if !settings.faceIDLockEnabled || unlocked {
                content()
            } else {
                VStack(spacing: 18) {
                    Image(systemName: "faceid").font(.system(size: 64))
                    Text("LocalRapPlayer Locked").font(.title2.bold())
                    if !errorText.isEmpty { Text(errorText).font(.footnote).foregroundStyle(.secondary) }
                    Button("Unlock") { authenticate() }.buttonStyle(.borderedProminent)
                }.padding()
            }
        }
        .onAppear { if settings.faceIDLockEnabled { authenticate() } else { unlocked = true } }
        .onChange(of: scenePhase) { _, phase in
            if phase != .active && settings.faceIDLockEnabled { unlocked = false }
            if phase == .active && settings.faceIDLockEnabled && !unlocked { authenticate() }
        }
    }

    private func authenticate() {
        let context = LAContext()
        var error: NSError?
        guard context.canEvaluatePolicy(.deviceOwnerAuthentication, error: &error) else { errorText = "Device authentication is unavailable."; return }
        context.evaluatePolicy(.deviceOwnerAuthentication, localizedReason: "Unlock your private music library") { success, error in
            DispatchQueue.main.async { unlocked = success; errorText = success ? "" : (error?.localizedDescription ?? "Authentication failed") }
        }
    }
}
