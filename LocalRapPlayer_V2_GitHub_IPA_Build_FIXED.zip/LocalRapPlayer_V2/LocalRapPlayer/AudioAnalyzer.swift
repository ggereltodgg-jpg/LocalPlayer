import Foundation
import AVFoundation

struct AudioAnalysisResult {
    var bpm: Double?
    var key: String?
    var replayGainDB: Double?
}

enum AudioAnalyzer {
    static func analyze(url: URL, maxSeconds: Double = 35) throws -> AudioAnalysisResult {
        let file = try AVAudioFile(forReading: url)
        let format = file.processingFormat
        let sampleRate = format.sampleRate
        let maxFrames = AVAudioFramePosition(maxSeconds * sampleRate)
        let framesToRead = min(file.length, maxFrames)
        let chunk: AVAudioFrameCount = 4096
        guard let buffer = AVAudioPCMBuffer(pcmFormat: format, frameCapacity: chunk) else {
            return AudioAnalysisResult(bpm: nil, key: nil, replayGainDB: nil)
        }

        var sumSquares = 0.0
        var sampleCount = 0
        var envelope: [Double] = []
        var chroma = Array(repeating: 0.0, count: 12)
        var remaining = framesToRead

        while remaining > 0 {
            let request = AVAudioFrameCount(min(AVAudioFramePosition(chunk), remaining))
            try file.read(into: buffer, frameCount: request)
            guard buffer.frameLength > 0 else { break }

            if let channels = buffer.floatChannelData {
                let n = Int(buffer.frameLength)
                var blockEnergy = 0.0
                for i in 0..<n {
                    var mono = 0.0
                    for c in 0..<Int(format.channelCount) {
                        mono += Double(channels[c][i])
                    }
                    mono /= Double(max(1, Int(format.channelCount)))
                    let sq = mono * mono
                    sumSquares += sq
                    blockEnergy += sq
                    sampleCount += 1
                }
                envelope.append(sqrt(blockEnergy / Double(max(n, 1))))

                // Lightweight musical-key estimate using Goertzel energy across 3 octaves.
                let monoSamples = (0..<n).map { i -> Double in
                    var mono = 0.0
                    for c in 0..<Int(format.channelCount) { mono += Double(channels[c][i]) }
                    return mono / Double(max(1, Int(format.channelCount)))
                }
                for pc in 0..<12 {
                    var energy = 0.0
                    for octave in 3...5 {
                        let midi = Double((octave + 1) * 12 + pc)
                        let frequency = 440.0 * pow(2.0, (midi - 69.0) / 12.0)
                        energy += goertzelPower(samples: monoSamples, sampleRate: sampleRate, frequency: frequency)
                    }
                    chroma[pc] += energy
                }
            }
            remaining -= AVAudioFramePosition(buffer.frameLength)
        }

        let rms = sampleCount > 0 ? sqrt(sumSquares / Double(sampleCount)) : 0
        let dbFS = rms > 0 ? 20.0 * log10(rms) : -60
        let target = -18.0
        let gain = max(-12.0, min(12.0, target - dbFS))
        let bpm = estimateBPM(envelope: envelope, blockSize: Double(chunk), sampleRate: sampleRate)
        let key = estimateKey(chroma: chroma)
        return AudioAnalysisResult(bpm: bpm, key: key, replayGainDB: gain)
    }

    private static func estimateBPM(envelope: [Double], blockSize: Double, sampleRate: Double) -> Double? {
        guard envelope.count > 20 else { return nil }
        let mean = envelope.reduce(0, +) / Double(envelope.count)
        let centered = envelope.map { $0 - mean }
        let envRate = sampleRate / blockSize
        var bestBPM: Double?
        var bestScore = -Double.infinity
        for bpm in stride(from: 70.0, through: 180.0, by: 0.5) {
            let lag = Int((60.0 / bpm) * envRate)
            guard lag > 0, lag < centered.count else { continue }
            var score = 0.0
            for i in lag..<centered.count { score += centered[i] * centered[i - lag] }
            if score > bestScore { bestScore = score; bestBPM = bpm }
        }
        return bestBPM
    }

    private static func goertzelPower(samples: [Double], sampleRate: Double, frequency: Double) -> Double {
        guard !samples.isEmpty, frequency > 0, frequency < sampleRate / 2 else { return 0 }
        let omega = 2.0 * Double.pi * frequency / sampleRate
        let coeff = 2.0 * cos(omega)
        var s0 = 0.0, s1 = 0.0, s2 = 0.0
        for sample in samples {
            s0 = sample + coeff * s1 - s2
            s2 = s1
            s1 = s0
        }
        return s1 * s1 + s2 * s2 - coeff * s1 * s2
    }

    private static func estimateKey(chroma: [Double]) -> String? {
        guard chroma.count == 12, chroma.reduce(0, +) > 0 else { return nil }
        let major = [6.35, 2.23, 3.48, 2.33, 4.38, 4.09, 2.52, 5.19, 2.39, 3.66, 2.29, 2.88]
        let minor = [6.33, 2.68, 3.52, 5.38, 2.60, 3.53, 2.54, 4.75, 3.98, 2.69, 3.34, 3.17]
        let names = ["C", "C♯", "D", "D♯", "E", "F", "F♯", "G", "G♯", "A", "A♯", "B"]
        var bestScore = -Double.infinity
        var bestName: String?
        for root in 0..<12 {
            let majorScore = (0..<12).reduce(0.0) { $0 + chroma[($1 + root) % 12] * major[$1] }
            let minorScore = (0..<12).reduce(0.0) { $0 + chroma[($1 + root) % 12] * minor[$1] }
            if majorScore > bestScore { bestScore = majorScore; bestName = "\(names[root]) major" }
            if minorScore > bestScore { bestScore = minorScore; bestName = "\(names[root]) minor" }
        }
        return bestName
    }
}
