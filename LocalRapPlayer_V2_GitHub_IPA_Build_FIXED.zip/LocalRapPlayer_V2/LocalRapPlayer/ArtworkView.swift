import SwiftUI
import UIKit

struct ArtworkView: View {
    let track: Track
    var size: CGFloat = 52

    var body: some View {
        Group {
            if let url = AppPaths.artworkURL(for: track), let data = try? Data(contentsOf: url), let uiImage = UIImage(data: data) {
                Image(uiImage: uiImage).resizable().scaledToFill()
            } else {
                ZStack {
                    RoundedRectangle(cornerRadius: size * 0.18).fill(.quaternary)
                    Image(systemName: "music.note").font(.system(size: size * 0.35, weight: .semibold)).foregroundStyle(.secondary)
                }
            }
        }
        .frame(width: size, height: size)
        .clipShape(RoundedRectangle(cornerRadius: size * 0.18, style: .continuous))
    }
}
