import SwiftUI

struct SearchView: View {
    @ObservedObject var library: MusicLibrary
    @ObservedObject var playlists: PlaylistStore
    @ObservedObject var player: PlayerManager
    @State private var query = ""

    private var results: [Track] {
        guard !query.isEmpty else { return [] }
        return library.tracks.filter { $0.title.localizedCaseInsensitiveContains(query) || $0.artist.localizedCaseInsensitiveContains(query) || $0.album.localizedCaseInsensitiveContains(query) || $0.genre.localizedCaseInsensitiveContains(query) }
    }

    var body: some View {
        NavigationStack {
            List(results) { track in
                HStack {
                    SongRow(track: track, isCurrent: player.currentTrack?.id == track.id, isPlaying: player.isPlaying).onTapGesture { player.play(track, in: results) }
                    TrackActionsView(track: track, library: library, playlists: playlists, player: player)
                }
            }
            .overlay { if query.isEmpty { ContentUnavailableView("Search Your Music", systemImage: "magnifyingglass", description: Text("Song, artist, album or genre")) } }
            .navigationTitle("Search")
            .searchable(text: $query, prompt: "Future, Travis, album…")
            .safeAreaInset(edge: .bottom) { MiniPlayerView(player: player) }
        }
    }
}
