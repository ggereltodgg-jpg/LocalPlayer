import SwiftUI

struct SearchView: View {
    @ObservedObject var library: MusicLibrary
    @ObservedObject var playlists: PlaylistStore
    let player: PlayerManager
    @StateObject private var playbackState: PlaybackListState
    @State private var query = ""

    init(library: MusicLibrary, playlists: PlaylistStore, player: PlayerManager) {
        self.library = library
        self.playlists = playlists
        self.player = player
        _playbackState = StateObject(wrappedValue: PlaybackListState(player: player))
    }

    private var results: [Track] {
        guard !query.isEmpty else { return [] }
        return library.tracks.filter {
            $0.title.localizedCaseInsensitiveContains(query) ||
            $0.artist.localizedCaseInsensitiveContains(query) ||
            $0.album.localizedCaseInsensitiveContains(query) ||
            $0.genre.localizedCaseInsensitiveContains(query) ||
            $0.country.localizedCaseInsensitiveContains(query)
        }
    }

    var body: some View {
        NavigationStack {
            List(results) { track in
                HStack {
                    SongRow(
                        track: track,
                        isCurrent: playbackState.currentTrackID == track.id,
                        isPlaying: playbackState.isPlaying
                    )
                    .onTapGesture { player.play(track, in: results) }
                    TrackActionsView(track: track, library: library, playlists: playlists, player: player)
                }
            }
            .overlay {
                if query.isEmpty {
                    ContentUnavailableView("Search Your Music", systemImage: "magnifyingglass", description: Text("Song, artist, album, genre or country"))
                }
            }
            .navigationTitle("Search")
            .searchable(text: $query, prompt: "Future, Travis, Korea…")
            .safeAreaInset(edge: .bottom) { MiniPlayerView(player: player) }
        }
    }
}
