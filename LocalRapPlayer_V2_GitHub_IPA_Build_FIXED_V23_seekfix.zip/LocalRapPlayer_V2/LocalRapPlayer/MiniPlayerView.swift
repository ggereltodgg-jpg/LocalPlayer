import SwiftUI

struct MiniPlayerView: View {
    let player: PlayerManager
    @StateObject private var playbackState: PlaybackListState
    @State private var showNowPlaying = false

    init(player: PlayerManager) {
        self.player = player
        _playbackState = StateObject(wrappedValue: PlaybackListState(player: player))
    }

    var body: some View {
        if let track = playbackState.currentTrack {
            HStack(spacing: 10) {
                ArtworkView(track: track, size: 44)
                VStack(alignment: .leading, spacing: 2) {
                    Text(track.title).font(.subheadline.weight(.semibold)).lineLimit(1)
                    Text(track.artist).font(.caption).foregroundStyle(.secondary).lineLimit(1)
                }
                Spacer()
                Button(action: player.togglePlayPause) {
                    Image(systemName: playbackState.isPlaying ? "pause.fill" : "play.fill").font(.title3)
                }
                Button { player.next() } label: { Image(systemName: "forward.fill").font(.title3) }
            }
            .padding(.horizontal, 12).padding(.vertical, 8)
            .background(.ultraThinMaterial)
            .clipShape(RoundedRectangle(cornerRadius: 16, style: .continuous))
            .padding(.horizontal, 8)
            .onTapGesture { showNowPlaying = true }
            .sheet(isPresented: $showNowPlaying) { NowPlayingView(player: player) }
        }
    }
}
