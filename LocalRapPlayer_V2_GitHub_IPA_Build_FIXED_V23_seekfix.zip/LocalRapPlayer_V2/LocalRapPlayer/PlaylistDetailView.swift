import SwiftUI

struct PlaylistDetailView: View {
    let playlist: Playlist
    @ObservedObject var library: MusicLibrary
    @ObservedObject var playlists: PlaylistStore
    let player: PlayerManager
    @StateObject private var playbackState: PlaybackListState

    init(playlist: Playlist, library: MusicLibrary, playlists: PlaylistStore, player: PlayerManager) {
        self.playlist = playlist
        self.library = library
        self.playlists = playlists
        self.player = player
        _playbackState = StateObject(wrappedValue: PlaybackListState(player: player))
    }

    private var livePlaylist: Playlist? { playlists.playlists.first(where: { $0.id == playlist.id }) }
    private var tracks: [Track] { (livePlaylist?.trackIDs ?? []).compactMap { id in library.tracks.first(where: { $0.id == id }) } }

    var body: some View {
        List {
            Section {
                HStack {
                    Button { player.playQueue(tracks) } label: { Label("Play", systemImage: "play.fill") }.buttonStyle(.borderedProminent)
                    Button { player.playQueue(tracks, smartShuffle: true) } label: { Label("Smart Shuffle", systemImage: "shuffle") }.buttonStyle(.bordered)
                }
            }
            ForEach(tracks) { track in
                HStack {
                    SongRow(
                        track: track,
                        isCurrent: playbackState.currentTrackID == track.id,
                        isPlaying: playbackState.isPlaying
                    )
                    .onTapGesture { player.play(track, in: tracks) }
                    Spacer()
                    Button(role: .destructive) { playlists.remove(track.id, from: playlist.id) } label: { Image(systemName: "minus.circle") }
                }
            }
            .onMove { source, dest in playlists.moveTracks(in: playlist.id, from: source, to: dest) }
        }
        .environment(\.editMode, .constant(.active))
        .navigationTitle(livePlaylist?.name ?? playlist.name)
        .safeAreaInset(edge: .bottom) { MiniPlayerView(player: player) }
    }
}
