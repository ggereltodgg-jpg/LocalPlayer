import Foundation
import MediaPlayer
import UIKit

@MainActor
enum MediaLibrarySupport {
    private static var itemCache: [UInt64: MPMediaItem] = [:]
    private static let artworkCache: NSCache<NSString, UIImage> = {
        let cache = NSCache<NSString, UIImage>()
        cache.countLimit = 350
        cache.totalCostLimit = 96 * 1024 * 1024
        return cache
    }()

    static func cache(_ items: [MPMediaItem]) {
        itemCache.removeAll(keepingCapacity: true)
        itemCache.reserveCapacity(items.count)
        for item in items {
            itemCache[UInt64(item.persistentID)] = item
        }
    }

    static func item(for persistentID: UInt64) -> MPMediaItem? {
        if let cached = itemCache[persistentID] { return cached }
        let query = MPMediaQuery.songs()
        let predicate = MPMediaPropertyPredicate(
            value: NSNumber(value: persistentID),
            forProperty: MPMediaItemPropertyPersistentID
        )
        query.addFilterPredicate(predicate)
        let item = query.items?.first
        if let item { itemCache[persistentID] = item }
        return item
    }

    static func audioURL(for track: Track) -> URL? {
        switch track.sourceKind {
        case .importedFile:
            return AppPaths.audioURL(for: track)
        case .mediaLibrary:
            guard let persistentID = track.mediaPersistentID,
                  let item = item(for: persistentID),
                  !item.hasProtectedAsset else { return nil }
            return item.assetURL
        }
    }

    static func artworkImage(for track: Track, size: CGSize) -> UIImage? {
        guard track.sourceKind == .mediaLibrary,
              let persistentID = track.mediaPersistentID,
              let item = item(for: persistentID),
              let artwork = item.artwork else { return nil }

        let albumID = UInt64(item.albumPersistentID)
        let bucket = max(64, Int(max(size.width, size.height).rounded(.up)))
        let key = "\(albumID)-\(bucket)" as NSString
        if let cached = artworkCache.object(forKey: key) { return cached }

        guard let image = artwork.image(at: CGSize(width: bucket, height: bucket)) else { return nil }
        let cost = max(1, Int(image.size.width * image.size.height * image.scale * image.scale * 4))
        artworkCache.setObject(image, forKey: key, cost: cost)
        return image
    }

    static func artworkData(for track: Track, size: CGSize = CGSize(width: 900, height: 900)) -> Data? {
        artworkImage(for: track, size: size)?.jpegData(compressionQuality: 0.88)
    }
}
