import SwiftUI

struct AlbumsView: View {
    @ObservedObject var library: MusicLibrary
    @ObservedObject var playlists: PlaylistStore
    let player: PlayerManager

    var body: some View {
        List(library.albums, id: \.self) { album in
            let tracks = library.tracks(forAlbum: album)
            NavigationLink {
                TrackCollectionView(title: album, subtitle: tracks.first?.artist ?? "", tracks: tracks, library: library, playlists: playlists, player: player)
            } label: {
                HStack {
                    if let first = tracks.first { ArtworkView(track: first, size: 54) }
                    VStack(alignment: .leading) { Text(album).font(.headline).lineLimit(1); Text("\(tracks.first?.artist ?? "") • \(tracks.count) songs").font(.caption).foregroundStyle(.secondary).lineLimit(1) }
                }
            }
        }.navigationTitle("Albums")
    }
}
