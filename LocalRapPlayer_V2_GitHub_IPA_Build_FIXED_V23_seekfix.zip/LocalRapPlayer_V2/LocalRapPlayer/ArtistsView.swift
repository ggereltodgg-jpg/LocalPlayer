import SwiftUI

struct ArtistsView: View {
    @ObservedObject var library: MusicLibrary
    @ObservedObject var playlists: PlaylistStore
    let player: PlayerManager

    var body: some View {
        List(library.artists, id: \.self) { artist in
            NavigationLink {
                TrackCollectionView(title: artist, subtitle: "\(library.tracks(forArtist: artist).count) songs", tracks: library.tracks(forArtist: artist), library: library, playlists: playlists, player: player)
            } label: {
                VStack(alignment: .leading) { Text(artist).font(.headline); Text("\(library.tracks(forArtist: artist).count) songs").font(.caption).foregroundStyle(.secondary) }
            }
        }.navigationTitle("Artists")
    }
}
