import SwiftUI
import UniformTypeIdentifiers
import MediaPlayer

struct LibraryView: View {
    @ObservedObject var library: MusicLibrary
    @ObservedObject var playlists: PlaylistStore
    let player: PlayerManager
    @ObservedObject var settings: SettingsStore

    @State private var searchText = ""
    @State private var displayedTracks: [Track] = []
    @State private var isPreparingList = false
    @State private var listTask: Task<Void, Never>?
    @State private var showFilesImporter = false
    @State private var showFolderImporter = false
    @State private var showPlaylistImporter = false

    @AppStorage("LibrarySortOptionV24") private var sortOptionRaw = LibrarySortOption.dateAddedNewest.rawValue

    private var sortOption: LibrarySortOption {
        LibrarySortOption(rawValue: sortOptionRaw) ?? .dateAddedNewest
    }

    var body: some View {
        NavigationStack {
            Group {
                if library.tracks.isEmpty {
                    ContentUnavailableView {
                        Label("No Music Yet", systemImage: "music.note.list")
                    } description: {
                        Text("Use your iPhone Music library or import M4A, MP3, AAC, FLAC files from Files.")
                    } actions: {
                        VStack(spacing: 10) {
                            Button("Use iPhone Music Library") { Task { await library.requestAndSyncIPhoneMusic() } }
                                .buttonStyle(.borderedProminent)
                            Button("Import Music Files") { showFilesImporter = true }
                                .buttonStyle(.bordered)
                        }
                    }
                } else {
                    List {
                        if library.isImporting || !library.importStatus.isEmpty || !library.analysisProgress.isEmpty || isPreparingList {
                            Section {
                                if library.isImporting {
                                    HStack {
                                        ProgressView()
                                        Text(library.importStatus).font(.footnote).foregroundStyle(.secondary)
                                    }
                                } else if isPreparingList {
                                    HStack {
                                        ProgressView()
                                        Text("Preparing songs…").font(.footnote).foregroundStyle(.secondary)
                                    }
                                } else if !library.importStatus.isEmpty {
                                    Text(library.importStatus).font(.footnote).foregroundStyle(.secondary)
                                }

                                if !library.analysisProgress.isEmpty {
                                    Text(library.analysisProgress).font(.footnote).foregroundStyle(.secondary)
                                }
                            }
                        }

                        Section("iTunes / iPhone Music") {
                            Button { Task { await library.requestAndSyncIPhoneMusic() } } label: {
                                Label(
                                    library.mediaLibraryAuthorization == .authorized ? "Sync iPhone Music" : "Connect iPhone Music",
                                    systemImage: "music.note.house.fill"
                                )
                            }

                            HStack {
                                VStack(alignment: .leading, spacing: 2) {
                                    Text(library.mediaLibraryStatusText)
                                    if let lastSync = library.lastMediaLibrarySyncDate {
                                        Text("Last sync: \(lastSync.formatted(date: .abbreviated, time: .shortened))")
                                            .foregroundStyle(.secondary)
                                    } else if library.mediaLibraryTrackCount > 0 {
                                        Text("Cached library loaded — no automatic rescan on launch")
                                            .foregroundStyle(.secondary)
                                    }
                                }
                                Spacer()
                                if library.mediaLibraryTrackCount > 0 {
                                    Text("\(library.mediaLibraryTrackCount)").foregroundStyle(.secondary)
                                }
                            }
                            .font(.footnote)

                            if library.mediaLibraryTrackCount > 0 {
                                Button("Restore Hidden Synced Songs") { Task { await library.restoreHiddenIPhoneMusic() } }
                                    .font(.footnote)
                            }
                        }

                        Section {
                            Button { player.playQueue(displayedTracks, smartShuffle: true) } label: {
                                Label("Smart Shuffle", systemImage: "shuffle.circle.fill")
                            }
                            NavigationLink { ArtistsView(library: library, playlists: playlists, player: player) } label: {
                                Label("Artists", systemImage: "person.2.fill")
                            }
                            NavigationLink { AlbumsView(library: library, playlists: playlists, player: player) } label: {
                                Label("Albums", systemImage: "square.stack.fill")
                            }
                            NavigationLink { FolderView(library: library, playlists: playlists, player: player) } label: {
                                Label("Folders", systemImage: "folder.fill")
                            }
                            NavigationLink { StatsView(library: library) } label: {
                                Label("Listening Stats", systemImage: "chart.bar.xaxis")
                            }
                        }

                        Section {
                            ForEach(displayedTracks) { track in
                                LibrarySongRow(
                                    track: track,
                                    playContext: displayedTracks,
                                    library: library,
                                    playlists: playlists,
                                    player: player
                                )
                            }
                        } header: {
                            HStack {
                                Text("\(displayedTracks.count) Songs")
                                Spacer()
                                Text(sortOption.title)
                                    .font(.caption)
                                    .foregroundStyle(.secondary)
                                    .lineLimit(1)
                            }
                        }
                    }
                    .listStyle(.plain)
                }
            }
            .navigationTitle("My Music")
            .searchable(text: $searchText, prompt: "Songs, artists, albums, genres")
            .toolbar {
                ToolbarItemGroup(placement: .topBarTrailing) {
                    Menu {
                        Picker("Sort By", selection: $sortOptionRaw) {
                            ForEach(LibrarySortOption.allCases) { option in
                                Label(option.title, systemImage: option.systemImage)
                                    .tag(option.rawValue)
                            }
                        }

                        if sortOption == .random {
                            Divider()
                            Button("Reshuffle", systemImage: "shuffle") {
                                refreshDisplayedTracks()
                            }
                        }
                    } label: {
                        Image(systemName: "arrow.up.arrow.down.circle.fill")
                    }

                    Menu {
                        Button("Import Audio Files", systemImage: "music.note") { showFilesImporter = true }
                        Button("Import Folder", systemImage: "folder") { showFolderImporter = true }
                        Button("Sync iTunes Music from iPhone", systemImage: "music.note.house") {
                            Task { await library.requestAndSyncIPhoneMusic() }
                        }
                        Button("Import iTunes / M3U Playlist", systemImage: "text.badge.plus") { showPlaylistImporter = true }
                    } label: {
                        Image(systemName: "plus.circle.fill")
                    }
                }
            }
            .safeAreaInset(edge: .bottom) { MiniPlayerView(player: player) }
            .fileImporter(isPresented: $showFilesImporter, allowedContentTypes: [.audio], allowsMultipleSelection: true) { result in
                if case .success(let urls) = result { Task { await library.importFiles(urls) } }
            }
            .fileImporter(isPresented: $showFolderImporter, allowedContentTypes: [.folder], allowsMultipleSelection: false) { result in
                if case .success(let urls) = result, let folder = urls.first { Task { await library.importFolder(folder) } }
            }
            .fileImporter(isPresented: $showPlaylistImporter, allowedContentTypes: [.xml, .plainText], allowsMultipleSelection: false) { result in
                if case .success(let urls) = result, let url = urls.first {
                    library.importPlaylistFile(url, playlistStore: playlists)
                }
            }
            .task {
                if displayedTracks.isEmpty { refreshDisplayedTracks() }
            }
            .onChange(of: searchText) { _, _ in
                refreshDisplayedTracks(debounce: true)
            }
            .onChange(of: sortOptionRaw) { _, _ in
                refreshDisplayedTracks()
            }
            .onChange(of: library.tracks.count) { _, _ in
                refreshDisplayedTracks()
            }
            .onChange(of: library.isImporting) { _, isImporting in
                if !isImporting { refreshDisplayedTracks() }
            }
            .onDisappear {
                listTask?.cancel()
            }
        }
    }

    private func refreshDisplayedTracks(debounce: Bool = false) {
        listTask?.cancel()
        let snapshot = library.tracks
        let query = searchText
        let option = sortOption
        isPreparingList = true

        listTask = Task { @MainActor in
            if debounce {
                try? await Task.sleep(for: .milliseconds(180))
                guard !Task.isCancelled else { return }
            }

            let result = await Task.detached(priority: .userInitiated) {
                LibrarySorter.filterAndSort(snapshot, query: query, option: option)
            }.value

            guard !Task.isCancelled else { return }
            displayedTracks = result
            isPreparingList = false
        }
    }
}
