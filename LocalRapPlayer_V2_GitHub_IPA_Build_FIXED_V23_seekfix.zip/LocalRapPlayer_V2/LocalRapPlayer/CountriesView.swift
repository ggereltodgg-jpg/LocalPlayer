import SwiftUI

struct CountriesView: View {
    @ObservedObject var library: MusicLibrary
    @ObservedObject var playlists: PlaylistStore
    let player: PlayerManager

    var body: some View {
        List {
            ForEach(library.countries, id: \.self) { country in
                let tracks = library.tracks(forCountry: country)
                NavigationLink {
                    TrackCollectionView(
                        title: country,
                        subtitle: "\(tracks.count) songs",
                        tracks: tracks,
                        library: library,
                        playlists: playlists,
                        player: player
                    )
                } label: {
                    HStack(spacing: 12) {
                        Image(systemName: icon(for: country))
                            .font(.title3)
                            .frame(width: 34, height: 34)
                            .background(.quaternary)
                            .clipShape(RoundedRectangle(cornerRadius: 9))
                        VStack(alignment: .leading, spacing: 2) {
                            Text(country)
                            Text("\(tracks.count) songs")
                                .font(.caption)
                                .foregroundStyle(.secondary)
                        }
                    }
                }
            }
        }
        .navigationTitle("Countries / Regions")
    }

    private func icon(for country: String) -> String {
        switch country {
        case "Mongolia": return "mountain.2.fill"
        case "South Korea": return "globe.asia.australia.fill"
        case "Canada": return "leaf.fill"
        case "United Kingdom": return "building.columns.fill"
        case "Australia": return "sun.max.fill"
        case "United States": return "star.fill"
        default: return "globe"
        }
    }
}
