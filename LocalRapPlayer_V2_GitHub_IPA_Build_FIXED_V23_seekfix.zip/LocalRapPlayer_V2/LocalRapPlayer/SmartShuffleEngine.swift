import Foundation

struct SmartShuffleEngine {
    /// Fast artist-balanced shuffle designed for very large libraries (8k+ tracks).
    ///
    /// The old implementation repeatedly searched/removes from one large array,
    /// which becomes O(n²) and can freeze the UI when a mix is tapped. This
    /// implementation groups songs by artist once and then deals one song from
    /// each shuffled artist bucket per pass. In practice it keeps the same artist
    /// well separated while staying close to O(n).
    static func makeQueue(from tracks: [Track], artistGap: Int) -> [Track] {
        guard tracks.count > 2 else { return tracks.shuffled() }

        var grouped: [String: [Track]] = [:]
        grouped.reserveCapacity(min(tracks.count, 2048))

        for track in tracks.shuffled() {
            grouped[normalizedArtist(track.artist), default: []].append(track)
        }

        var buckets = grouped.map { ArtistBucket(artist: $0.key, tracks: $0.value.shuffled()) }
        buckets.shuffle()

        var result: [Track] = []
        result.reserveCapacity(tracks.count)
        let desiredGap = max(1, artistGap)

        while !buckets.isEmpty {
            // Prefer larger buckets first so a very prolific artist does not leave
            // a large tail of back-to-back songs at the end of the queue.
            buckets.sort { lhs, rhs in
                lhs.tracks.count > rhs.tracks.count
            }

            var usedThisPass = Set<String>()
            usedThisPass.reserveCapacity(buckets.count)
            var nextBuckets: [ArtistBucket] = []
            nextBuckets.reserveCapacity(buckets.count)
            var appendedThisPass = 0

            for var bucket in buckets {
                guard let track = bucket.tracks.popLast() else { continue }

                // If the artist is still inside the requested recent window, defer
                // this bucket to a later pass when possible.
                let recentArtists = Set(result.suffix(desiredGap).map { normalizedArtist($0.artist) })
                if recentArtists.contains(bucket.artist), buckets.count > 1, !usedThisPass.isEmpty {
                    bucket.tracks.append(track)
                    nextBuckets.append(bucket)
                    continue
                }

                result.append(track)
                appendedThisPass += 1
                usedThisPass.insert(bucket.artist)
                if !bucket.tracks.isEmpty { nextBuckets.append(bucket) }
            }

            // Safety: if every remaining bucket was deferred, force one item so
            // the loop can never stall.
            if appendedThisPass == 0,
               result.count < tracks.count,
               var first = nextBuckets.first,
               let forced = first.tracks.popLast() {
                result.append(forced)
                nextBuckets[0] = first
                nextBuckets.removeAll { $0.tracks.isEmpty }
            }

            buckets = nextBuckets
        }

        return result
    }

    private struct ArtistBucket {
        let artist: String
        var tracks: [Track]
    }

    private static func normalizedArtist(_ value: String) -> String {
        value.lowercased().trimmingCharacters(in: .whitespacesAndNewlines)
    }
}
