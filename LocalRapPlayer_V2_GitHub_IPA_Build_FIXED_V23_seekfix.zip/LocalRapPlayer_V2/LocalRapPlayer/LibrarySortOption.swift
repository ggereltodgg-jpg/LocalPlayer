import Foundation

enum LibrarySortOption: String, CaseIterable, Identifiable {
    case titleAZ
    case titleZA
    case artistAZ
    case artistZA
    case albumAZ
    case albumZA
    case dateAddedNewest
    case dateAddedOldest
    case yearNewest
    case yearOldest
    case recentlyPlayed
    case mostPlayed
    case leastPlayed
    case durationShortest
    case durationLongest
    case favoritesFirst
    case genreAZ
    case bpmLowHigh
    case bpmHighLow
    case random

    var id: String { rawValue }

    var title: String {
        switch self {
        case .titleAZ: return "Title A → Z"
        case .titleZA: return "Title Z → A"
        case .artistAZ: return "Artist A → Z"
        case .artistZA: return "Artist Z → A"
        case .albumAZ: return "Album A → Z"
        case .albumZA: return "Album Z → A"
        case .dateAddedNewest: return "Date Added — Newest"
        case .dateAddedOldest: return "Date Added — Oldest"
        case .yearNewest: return "Release Year — Newest"
        case .yearOldest: return "Release Year — Oldest"
        case .recentlyPlayed: return "Recently Played"
        case .mostPlayed: return "Most Played"
        case .leastPlayed: return "Least Played"
        case .durationShortest: return "Duration — Shortest"
        case .durationLongest: return "Duration — Longest"
        case .favoritesFirst: return "Favorites First"
        case .genreAZ: return "Genre A → Z"
        case .bpmLowHigh: return "BPM — Low → High"
        case .bpmHighLow: return "BPM — High → Low"
        case .random: return "Random Order"
        }
    }

    var systemImage: String {
        switch self {
        case .titleAZ, .titleZA: return "textformat"
        case .artistAZ, .artistZA: return "person.2"
        case .albumAZ, .albumZA: return "square.stack"
        case .dateAddedNewest, .dateAddedOldest: return "calendar.badge.plus"
        case .yearNewest, .yearOldest: return "calendar"
        case .recentlyPlayed: return "clock.arrow.circlepath"
        case .mostPlayed, .leastPlayed: return "chart.bar"
        case .durationShortest, .durationLongest: return "timer"
        case .favoritesFirst: return "heart.fill"
        case .genreAZ: return "guitars"
        case .bpmLowHigh, .bpmHighLow: return "metronome"
        case .random: return "shuffle"
        }
    }
}

enum LibrarySorter {
    static func filterAndSort(_ tracks: [Track], query: String, option: LibrarySortOption) -> [Track] {
        let trimmed = query.trimmingCharacters(in: .whitespacesAndNewlines)
        let base: [Track]
        if trimmed.isEmpty {
            base = tracks
        } else {
            base = tracks.filter {
                $0.title.localizedCaseInsensitiveContains(trimmed) ||
                $0.artist.localizedCaseInsensitiveContains(trimmed) ||
                $0.album.localizedCaseInsensitiveContains(trimmed) ||
                $0.genre.localizedCaseInsensitiveContains(trimmed)
            }
        }
        return sort(base, by: option)
    }

    static func sort(_ tracks: [Track], by option: LibrarySortOption) -> [Track] {
        switch option {
        case .titleAZ:
            return tracks.sorted { compareText($0.title, $1.title, ascending: true) }
        case .titleZA:
            return tracks.sorted { compareText($0.title, $1.title, ascending: false) }
        case .artistAZ:
            return tracks.sorted { compareArtistThenTitle($0, $1, ascending: true) }
        case .artistZA:
            return tracks.sorted { compareArtistThenTitle($0, $1, ascending: false) }
        case .albumAZ:
            return tracks.sorted { compareAlbumThenTrack($0, $1, ascending: true) }
        case .albumZA:
            return tracks.sorted { compareAlbumThenTrack($0, $1, ascending: false) }
        case .dateAddedNewest:
            return tracks.sorted { $0.dateAdded > $1.dateAdded }
        case .dateAddedOldest:
            return tracks.sorted { $0.dateAdded < $1.dateAdded }
        case .yearNewest:
            return tracks.sorted {
                let l = $0.year ?? Int.min
                let r = $1.year ?? Int.min
                return l == r ? compareArtistThenTitle($0, $1, ascending: true) : l > r
            }
        case .yearOldest:
            return tracks.sorted {
                let l = $0.year ?? Int.max
                let r = $1.year ?? Int.max
                return l == r ? compareArtistThenTitle($0, $1, ascending: true) : l < r
            }
        case .recentlyPlayed:
            return tracks.sorted {
                let l = $0.lastPlayed ?? .distantPast
                let r = $1.lastPlayed ?? .distantPast
                return l == r ? compareArtistThenTitle($0, $1, ascending: true) : l > r
            }
        case .mostPlayed:
            return tracks.sorted {
                $0.playCount == $1.playCount ? compareArtistThenTitle($0, $1, ascending: true) : $0.playCount > $1.playCount
            }
        case .leastPlayed:
            return tracks.sorted {
                $0.playCount == $1.playCount ? compareArtistThenTitle($0, $1, ascending: true) : $0.playCount < $1.playCount
            }
        case .durationShortest:
            return tracks.sorted {
                $0.duration == $1.duration ? compareArtistThenTitle($0, $1, ascending: true) : $0.duration < $1.duration
            }
        case .durationLongest:
            return tracks.sorted {
                $0.duration == $1.duration ? compareArtistThenTitle($0, $1, ascending: true) : $0.duration > $1.duration
            }
        case .favoritesFirst:
            return tracks.sorted {
                if $0.isFavorite != $1.isFavorite { return $0.isFavorite && !$1.isFavorite }
                if $0.rating != $1.rating { return $0.rating > $1.rating }
                return compareArtistThenTitle($0, $1, ascending: true)
            }
        case .genreAZ:
            return tracks.sorted {
                let l = $0.genre.isEmpty ? "ZZZZZZ" : $0.genre
                let r = $1.genre.isEmpty ? "ZZZZZZ" : $1.genre
                let order = l.localizedCaseInsensitiveCompare(r)
                return order == .orderedSame ? compareArtistThenTitle($0, $1, ascending: true) : order == .orderedAscending
            }
        case .bpmLowHigh:
            return tracks.sorted {
                let l = $0.bpm ?? Double.greatestFiniteMagnitude
                let r = $1.bpm ?? Double.greatestFiniteMagnitude
                return l == r ? compareArtistThenTitle($0, $1, ascending: true) : l < r
            }
        case .bpmHighLow:
            return tracks.sorted {
                let l = $0.bpm ?? -1
                let r = $1.bpm ?? -1
                return l == r ? compareArtistThenTitle($0, $1, ascending: true) : l > r
            }
        case .random:
            return tracks.shuffled()
        }
    }

    private static func compareText(_ lhs: String, _ rhs: String, ascending: Bool) -> Bool {
        let order = lhs.localizedCaseInsensitiveCompare(rhs)
        if order == .orderedSame { return lhs < rhs }
        return ascending ? order == .orderedAscending : order == .orderedDescending
    }

    private static func compareArtistThenTitle(_ lhs: Track, _ rhs: Track, ascending: Bool) -> Bool {
        let order = lhs.artist.localizedCaseInsensitiveCompare(rhs.artist)
        if order == .orderedSame { return compareText(lhs.title, rhs.title, ascending: ascending) }
        return ascending ? order == .orderedAscending : order == .orderedDescending
    }

    private static func compareAlbumThenTrack(_ lhs: Track, _ rhs: Track, ascending: Bool) -> Bool {
        let order = lhs.album.localizedCaseInsensitiveCompare(rhs.album)
        if order == .orderedSame {
            let ld = lhs.discNumber ?? 1
            let rd = rhs.discNumber ?? 1
            if ld != rd { return ascending ? ld < rd : ld > rd }
            let lt = lhs.trackNumber ?? Int.max
            let rt = rhs.trackNumber ?? Int.max
            if lt != rt { return ascending ? lt < rt : lt > rt }
            return compareText(lhs.title, rhs.title, ascending: ascending)
        }
        return ascending ? order == .orderedAscending : order == .orderedDescending
    }
}
