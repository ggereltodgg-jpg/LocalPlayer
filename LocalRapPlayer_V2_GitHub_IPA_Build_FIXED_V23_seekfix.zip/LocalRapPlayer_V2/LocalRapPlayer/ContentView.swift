import SwiftUI

struct ContentView: View {
    @ObservedObject var library: MusicLibrary
    @ObservedObject var playlists: PlaylistStore
    let player: PlayerManager
    @ObservedObject var settings: SettingsStore

    var body: some View {
        TabView {
            LibraryView(library: library, playlists: playlists, player: player, settings: settings)
                .tabItem { Label("Library", systemImage: "music.note.list") }
            SearchView(library: library, playlists: playlists, player: player)
                .tabItem { Label("Search", systemImage: "magnifyingglass") }
            PlaylistsView(library: library, playlists: playlists, player: player)
                .tabItem { Label("Playlists", systemImage: "music.note.list") }
            MixesView(library: library, player: player)
                .tabItem { Label("Mix", systemImage: "sparkles") }
            SettingsView(library: library, playlists: playlists, player: player, settings: settings)
                .tabItem { Label("Settings", systemImage: "gearshape") }
        }
    }
}
