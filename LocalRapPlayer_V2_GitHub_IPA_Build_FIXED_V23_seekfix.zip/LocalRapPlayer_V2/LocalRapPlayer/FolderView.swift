import SwiftUI

struct FolderView: View {
    @ObservedObject var library: MusicLibrary
    @ObservedObject var playlists: PlaylistStore
    let player: PlayerManager

    var body: some View {
        List(library.folders, id: \.self) { folder in
            let tracks = library.tracks(inFolder: folder)
            NavigationLink {
                TrackCollectionView(title: URL(fileURLWithPath: folder).lastPathComponent, subtitle: folder, tracks: tracks, library: library, playlists: playlists, player: player)
            } label: {
                Label { VStack(alignment: .leading) { Text(URL(fileURLWithPath: folder).lastPathComponent); Text("\(tracks.count) songs").font(.caption).foregroundStyle(.secondary) } } icon: { Image(systemName: "folder.fill") }
            }
        }.navigationTitle("Folders")
    }
}
