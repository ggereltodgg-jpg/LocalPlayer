import SwiftUI

struct MixesView: View {
    @ObservedObject var library: MusicLibrary
    let player: PlayerManager

    private let lateNightArtists = ["don toliver", "travis scott", "drake", "the weeknd", "tory lanez", "bryson tiller", "future", "gunna", "nav", "6lack", "brent faiyaz", "partynextdoor"]
    private let trapArtists = ["future", "young thug", "lil baby", "gunna", "42 dugg", "travis scott", "lil uzi", "kodak black", "lil durk", "est gee", "metro boomin", "21 savage", "offset", "quavo"]
    private let hardArtists = ["future", "21 savage", "lil durk", "est gee", "42 dugg", "kodak black", "nardo wick", "young nudy", "comethazine", "king von", "lil baby"]
    private let workoutArtists = ["travis scott", "future", "lil uzi", "young thug", "lil baby", "21 savage", "kodak black", "migos", "offset", "quavo", "polo g"]
    private let kRapArtists = ["changmo", "ash island", "sik-k", "ph-1", "pH-1", "kid milli", "homies", "fleeky bang", "haon", "justhis", "zico", "simon dominic"]

    private func artistMatches(_ track: Track, names: [String]) -> Bool {
        let artist = track.artist.lowercased()
        return names.contains { artist.contains($0.lowercased()) }
    }

    private func byArtists(_ names: [String]) -> [Track] {
        library.tracks.filter { artistMatches($0, names: names) }
    }

    private var lateNight: [Track] { byArtists(lateNightArtists) }
    private var trap: [Track] { byArtists(trapArtists) }

    // iTunes often has no BPM tag. Do not make these mixes empty just because
    // BPM was never embedded in the files; use artist/genre fallbacks instead.
    private var hardRap: [Track] {
        library.tracks.filter { track in
            let isRap = track.genre.lowercased().contains("rap") || track.genre.lowercased().contains("hip-hop")
            if let bpm = track.bpm { return isRap && bpm >= 118 }
            return isRap && artistMatches(track, names: hardArtists)
        }
    }

    private var chill: [Track] {
        library.tracks.filter { track in
            let genre = track.genre.lowercased()
            let smoothGenre = genre.contains("r&b") || genre.contains("soul")
            let smoothArtist = artistMatches(track, names: lateNightArtists)
            if let bpm = track.bpm { return bpm < 116 && (smoothGenre || smoothArtist) }
            return smoothGenre || smoothArtist
        }
    }

    private var workout: [Track] {
        library.tracks.filter { track in
            if let bpm = track.bpm { return bpm >= 122 }
            return artistMatches(track, names: workoutArtists)
        }
    }

    private var kRap: [Track] { byArtists(kRapArtists) }
    private var thisYear: [Track] {
        let year = Calendar.current.component(.year, from: Date())
        return library.tracks.filter { $0.year == year }
    }

    var body: some View {
        NavigationStack {
            List {
                MixCard(title: "Smart Shuffle", subtitle: "Artist-balanced whole library", icon: "shuffle.circle.fill", count: library.tracks.count) {
                    player.playQueue(library.tracks, smartShuffle: true)
                }
                MixCard(title: "Trap Run", subtitle: "Future, Thug, Gunna, Lil Baby…", icon: "bolt.fill", count: trap.count) {
                    player.playQueue(trap, smartShuffle: true)
                }
                MixCard(title: "Late Night", subtitle: "Melodic rap + R&B", icon: "moon.stars.fill", count: lateNight.count) {
                    player.playQueue(lateNight, smartShuffle: true)
                }
                MixCard(title: "Hard Rap", subtitle: "Hard rap — BPM when available", icon: "flame.fill", count: hardRap.count) {
                    player.playQueue(hardRap, smartShuffle: true)
                }
                MixCard(title: "Gym", subtitle: "High energy — BPM + artist fallback", icon: "figure.run", count: workout.count) {
                    player.playQueue(workout, smartShuffle: true)
                }
                MixCard(title: "Chill / R&B", subtitle: "Slower, smoother rotation", icon: "cloud.moon.fill", count: chill.count) {
                    player.playQueue(chill, smartShuffle: true)
                }
                MixCard(title: "K-Rap", subtitle: "Your Korean rap artists", icon: "globe.asia.australia.fill", count: kRap.count) {
                    player.playQueue(kRap, smartShuffle: true)
                }
                MixCard(title: "This Year", subtitle: "Current-year music", icon: "calendar", count: thisYear.count) {
                    player.playQueue(thisYear, smartShuffle: true)
                }
                MixCard(title: "Most Played", subtitle: "Your own rotation", icon: "chart.bar.fill", count: library.mostPlayed.count) {
                    player.playQueue(library.mostPlayed)
                }
                MixCard(title: "Recently Played", subtitle: "Your latest listens", icon: "clock.arrow.circlepath", count: library.recentlyPlayed.count) {
                    player.playQueue(library.recentlyPlayed)
                }
                MixCard(title: "Never Played", subtitle: "Rediscover forgotten imports", icon: "sparkles", count: library.neverPlayed.count) {
                    player.playQueue(library.neverPlayed, smartShuffle: true)
                }
                MixCard(title: "Recently Added", subtitle: "Newest imports", icon: "clock.fill", count: library.recentlyAdded.count) {
                    player.playQueue(library.recentlyAdded)
                }
            }
            .navigationTitle("Smart Mixes")
            .safeAreaInset(edge: .bottom) { MiniPlayerView(player: player) }
        }
    }
}

private struct MixCard: View {
    let title: String
    let subtitle: String
    let icon: String
    let count: Int
    let action: () -> Void

    var body: some View {
        Button(action: action) {
            HStack(spacing: 14) {
                ZStack {
                    RoundedRectangle(cornerRadius: 14).fill(.quaternary)
                    Image(systemName: icon).font(.title2)
                }
                .frame(width: 58, height: 58)

                VStack(alignment: .leading, spacing: 3) {
                    Text(title).font(.headline)
                    Text(subtitle).font(.subheadline).foregroundStyle(.secondary).lineLimit(1)
                    Text("\(count) songs").font(.caption).foregroundStyle(.tertiary)
                }
                Spacer()
                Image(systemName: "play.circle.fill").font(.title2)
            }
            .padding(.vertical, 4)
        }
        .buttonStyle(.plain)
        .disabled(count == 0)
    }
}
