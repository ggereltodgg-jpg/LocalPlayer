import SwiftUI

struct TrackCollectionView: View {
    let title: String
    let subtitle: String
    let tracks: [Track]
    @ObservedObject var library: MusicLibrary
    @ObservedObject var playlists: PlaylistStore
    let player: PlayerManager
    @StateObject private var playbackState: PlaybackListState

    init(title: String, subtitle: String, tracks: [Track], library: MusicLibrary, playlists: PlaylistStore, player: PlayerManager) {
        self.title = title
        self.subtitle = subtitle
        self.tracks = tracks
        self.library = library
        self.playlists = playlists
        self.player = player
        _playbackState = StateObject(wrappedValue: PlaybackListState(player: player))
    }

    var body: some View {
        List {
            Section {
                HStack {
                    Button { player.playQueue(tracks) } label: { Label("Play", systemImage: "play.fill") }.buttonStyle(.borderedProminent)
                    Button { player.playQueue(tracks, smartShuffle: true) } label: { Label("Shuffle", systemImage: "shuffle") }.buttonStyle(.bordered)
                }
            }
            ForEach(tracks) { track in
                HStack {
                    SongRow(
                        track: track,
                        isCurrent: playbackState.currentTrackID == track.id,
                        isPlaying: playbackState.isPlaying
                    )
                    .onTapGesture { player.play(track, in: tracks) }
                    TrackActionsView(track: track, library: library, playlists: playlists, player: player)
                }
            }
        }
        .navigationTitle(title)
        .navigationBarTitleDisplayMode(.large)
        .safeAreaInset(edge: .bottom) { MiniPlayerView(player: player) }
    }
}
