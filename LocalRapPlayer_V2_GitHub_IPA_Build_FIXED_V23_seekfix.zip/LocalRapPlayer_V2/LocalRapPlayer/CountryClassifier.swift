import Foundation

enum CountryClassifier {
    static let unknown = "Other / Unknown"

    static func infer(artist: String, genre: String) -> String {
        let a = normalize(artist)
        let g = normalize(genre)

        if containsAny(g, ["k-pop", "kpop", "korean", "k-rap", "k rap", "k hip hop", "k-hip-hop"]) {
            return "South Korea"
        }
        if containsAny(g, ["mongol", "mongolian"]) { return "Mongolia" }
        if containsAny(g, ["grime", "uk drill", "british hip hop", "british rap"]) { return "United Kingdom" }

        if matchesArtist(a, mongoliaArtists) { return "Mongolia" }
        if matchesArtist(a, koreaArtists) { return "South Korea" }
        if matchesArtist(a, canadaArtists) { return "Canada" }
        if matchesArtist(a, ukArtists) { return "United Kingdom" }
        if matchesArtist(a, australiaArtists) { return "Australia" }
        if matchesArtist(a, usArtists) { return "United States" }
        return unknown
    }

    private static func normalize(_ value: String) -> String {
        value.folding(options: [.diacriticInsensitive, .caseInsensitive], locale: .current)
            .lowercased()
            .replacingOccurrences(of: "&", with: " and ")
    }

    private static func containsAny(_ value: String, _ needles: [String]) -> Bool {
        needles.contains { value.contains($0) }
    }

    private static func matchesArtist(_ artist: String, _ names: [String]) -> Bool {
        names.contains { name in
            artist == name || artist.contains("\(name) feat") || artist.contains("\(name) and ") || artist.contains("\(name),")
        }
    }

    private static let mongoliaArtists = [
        "vandebo", "ginjin", "rokit bay", "thunderz", "mrs m", "the lemons", "niciton", "gangbay", "168"
    ]

    private static let koreaArtists = [
        "jay park", "dean", "zico", "changmo", "ash island", "sik-k", "ph-1", "p h-1", "haon", "kid milli",
        "homies", "fleeky bang", "justhis", "simon dominic", "mirani", "epik high", "code kunst", "the quiett",
        "crush", "woo", "jvcki wai", "mushvenom", "khundi panda", "no:el", "young b", "mokyo"
    ]

    private static let canadaArtists = [
        "drake", "tory lanez", "the weeknd", "nav", "partynextdoor", "justin bieber", "roy woods", "killy", "pressa"
    ]

    private static let ukArtists = [
        "central cee", "dave", "skepta", "stormzy", "j hus", "headie one", "lancey foux", "little simz", "21 savage"
    ]

    private static let australiaArtists = [
        "the kid laroi", "kid laroi", "iggy azalea"
    ]

    private static let usArtists = [
        "travis scott", "future", "chris brown", "gunna", "juice wrld", "playboi carti", "j. cole", "j cole",
        "kanye west", "don toliver", "lil uzi vert", "lil durk", "tyler the creator", "tyler, the creator",
        "lil baby", "young thug", "kendrick lamar", "kodak black", "metro boomin", "migos", "offset", "quavo",
        "21 savage", "polo g", "trippie redd", "bryson tiller", "mac miller", "asap rocky", "a$ap rocky",
        "giveon", "givēon", "joji", "xxxtentacion", "comethazine", "nle choppa", "42 dugg", "est gee",
        "nardo wick", "young nudy", "king von", "babyface ray", "veeze", "lil tjay", "saint jhn", "sahbabii",
        "lucki", "bigxthaplug", "that mexican ot", "mike dimes", "key glock", "tee grizzley", "lil yachty",
        "lil tecca", "a boogie wit da hoodie", "nas", "kid cudi", "sza", "doja cat", "meek mill"
    ]
}
