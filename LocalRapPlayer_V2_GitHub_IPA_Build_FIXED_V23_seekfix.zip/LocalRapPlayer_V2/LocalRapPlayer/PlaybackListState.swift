import Foundation
import Combine

@MainActor
final class PlaybackListState: ObservableObject {
    @Published private(set) var currentTrack: Track?
    @Published private(set) var currentTrackID: UUID?
    @Published private(set) var isPlaying = false

    private var cancellables = Set<AnyCancellable>()

    init(player: PlayerManager) {
        currentTrack = player.currentTrack
        currentTrackID = player.currentTrack?.id
        isPlaying = player.isPlaying

        player.$currentTrack
            .removeDuplicates { $0?.id == $1?.id }
            .sink { [weak self] track in
                self?.currentTrack = track
                self?.currentTrackID = track?.id
            }
            .store(in: &cancellables)

        player.$isPlaying
            .removeDuplicates()
            .sink { [weak self] value in self?.isPlaying = value }
            .store(in: &cancellables)
    }
}
