import SwiftUI

struct LibrarySongRow: View {
    let track: Track
    let playContext: [Track]
    let isCurrent: Bool
    let isPlaying: Bool
    @ObservedObject var library: MusicLibrary
    @ObservedObject var playlists: PlaylistStore
    let player: PlayerManager

    var body: some View {
        HStack {
            SongRow(
                track: track,
                isCurrent: isCurrent,
                isPlaying: isPlaying
            )
            .onTapGesture { player.play(track, in: playContext) }

            TrackActionsView(track: track, library: library, playlists: playlists, player: player)
        }
        .swipeActions(edge: .leading) {
            Button { library.toggleFavorite(track) } label: {
                Label("Favorite", systemImage: "heart")
            }
            .tint(.pink)
        }
        .swipeActions(edge: .trailing) {
            Button(role: .destructive) { library.delete(track) } label: {
                Label(track.sourceKind == .mediaLibrary ? "Hide" : "Delete", systemImage: "trash")
            }
        }
    }
}
