import SwiftUI
import UIKit

struct ArtworkView: View {
    let track: Track
    var size: CGFloat = 52
    @State private var image: UIImage?

    private static let localArtworkCache: NSCache<NSString, UIImage> = {
        let cache = NSCache<NSString, UIImage>()
        cache.countLimit = 350
        cache.totalCostLimit = 96 * 1024 * 1024
        return cache
    }()

    var body: some View {
        Group {
            if let image {
                Image(uiImage: image).resizable().scaledToFill()
            } else {
                ZStack {
                    RoundedRectangle(cornerRadius: size * 0.18).fill(.quaternary)
                    Image(systemName: "music.note")
                        .font(.system(size: size * 0.35, weight: .semibold))
                        .foregroundStyle(.secondary)
                }
            }
        }
        .frame(width: size, height: size)
        .clipShape(RoundedRectangle(cornerRadius: size * 0.18, style: .continuous))
        .task(id: "\(track.id.uuidString)-\(Int(size))") {
            await loadArtwork()
        }
    }

    @MainActor
    private func loadArtwork() async {
        if track.sourceKind == .mediaLibrary {
            image = MediaLibrarySupport.artworkImage(
                for: track,
                size: CGSize(width: min(size * 2.2, 900), height: min(size * 2.2, 900))
            )
            return
        }

        guard let url = AppPaths.artworkURL(for: track) else { return }
        let bucket = max(64, Int((size * 2.2).rounded(.up)))
        let key = "\(track.artworkFileName ?? track.id.uuidString)-\(bucket)" as NSString
        if let cached = Self.localArtworkCache.object(forKey: key) {
            image = cached
            return
        }

        let data = await Task.detached(priority: .utility) {
            try? Data(contentsOf: url)
        }.value

        guard let data, let loaded = UIImage(data: data) else { return }
        let cost = max(1, Int(loaded.size.width * loaded.size.height * loaded.scale * loaded.scale * 4))
        Self.localArtworkCache.setObject(loaded, forKey: key, cost: cost)
        image = loaded
    }
}
