# LocalRapPlayer V2.1

## New: iTunes-synced iPhone Music
On first launch, tap **Use iPhone Music Library**, allow Music access, and the app will index locally available songs that were synced to the iPhone with iTunes. After permission is granted, the app refreshes this library on later launches. Audio is referenced in place rather than copied, so it does not duplicate the full music library inside the app. DRM-protected or cloud-only items may be unavailable to this custom audio engine.

# LocalRapPlayer V2

Private SwiftUI iPhone music player for a large local library. Designed around downloaded/purchased M4A, MP3, AAC and FLAC files and a rap-heavy library.

## What's new in V2

V2 expands the original starter into a much fuller local player: smart shuffle, editable playlists, iTunes/M3U playlist import, queue editing, crossfade, 10-band EQ presets, bass boost, volume normalization, lyrics, metadata editing, duplicate/missing-file tools, BPM/key analysis, stats, backup/restore, Face ID lock, Car Mode and extension templates for Widgets/CarPlay.

See `FEATURE_MATRIX.md` for the complete list.

## V2.4 performance + sorting

The Library now has a persistent Sort menu with Title, Artist, Album, Date Added, Release Year, play history/count, duration, favorites, genre, BPM and random ordering. Search/sort runs off the main thread and the displayed list is cached, which is especially important for 8,000+ synced iTunes tracks. Playback listening-time accounting and routine saves were also changed to avoid publishing/JSON-encoding the entire library on every timer tick.

## Build

Requirements: a Mac with Xcode 16+ and iOS 17+ recommended.

1. Xcode → **Create a new project** → iOS → App.
2. Product Name: `LocalRapPlayer`.
3. Interface: SwiftUI. Language: Swift.
4. Delete Xcode's generated `ContentView.swift` and app file.
5. Drag every `.swift` file from this package's `LocalRapPlayer` folder into the main target.
6. Target → **Signing & Capabilities** → choose your Apple ID / team.
7. Add **Background Modes** and tick **Audio, AirPlay, and Picture in Picture**.
8. In target Info, add **Privacy - Face ID Usage Description** with: `Use Face ID to unlock your private local music library.`
9. Run on your iPhone.

The `ExtensionTemplates` folder is NOT meant to be dragged wholesale into the main target. Read the comments in each file first.

## Upgrade from V1

If you already installed the original source build with the same bundle identifier, V2's `Track` decoder is backwards-compatible with the earlier `library.json`. Existing songs/favorites/play counts should continue to load. New fields default safely.

If you make a fresh app with a new bundle identifier, iOS treats it as a separate app and its private imported music will not automatically appear.

## Importing a large Windows library

For a library of thousands of tracks:

1. Put your music folder on iCloud Drive, a USB-C drive, or another location visible in the iPhone Files app.
2. Open LocalRapPlayer → Library → `+` → **Import Folder**.
3. Pick the root music folder once.
4. The app recursively copies supported files into its private storage and keeps the relative folder path for Folder View.

Test with 100–300 songs first before importing the full collection. You need enough free storage on the phone for another copy of the files.

## iTunes playlist import

After your songs are imported, choose Library → `+` → **Import iTunes / M3U Playlist**.

Supported:
- iTunes Library XML / exported playlist XML
- M3U
- M3U8

Matching is based on title+artist and/or original filename, so playlist matching works best if the music files were imported without renaming their original filenames before import.

## Audio analysis

Open Settings → Library Tools. You can analyze one track from its `…` menu or batch-analyze missing values. The analyzer estimates:

- BPM
- musical key
- replay-gain/loudness adjustment

It runs locally and can take time on a very large library. Analyze a small batch first.

## EQ / crossfade / normalization

The playback engine is based on `AVAudioEngine` and two `AVAudioPlayerNode`s. The EQ uses ten bands and the included presets are Flat, Rap, Bass Boost, Vocal, R&B and Car. Crossfade can be set from 0–10 seconds.

Normalization uses the per-track local loudness estimate. Tracks that have not yet been analyzed play at normal volume.

## Lyrics

Open a song's `…` menu → Lyrics → Import. Synced `.lrc` files scroll with playback and tapping a lyric line seeks to that timestamp. Plain text lyrics are displayed without sync.

## Backup

Settings → Backup creates a small JSON backup containing favorites, ratings, play/skip stats, audio-analysis values and playlists. It does not copy the audio files themselves.

To restore on a new install: import the same audio files first, then restore the JSON backup so LocalRapPlayer can match data by original filename.

## Widgets

Create a Widget Extension in Xcode, enable the same App Group on the app and widget, then adapt `ExtensionTemplates/RecentMusicWidget.swift` to your bundle/App Group identifier. The included file is a target template, not an automatically configured extension.

## CarPlay

The in-app **Car Mode** is fully available without CarPlay entitlement. Native CarPlay integration requires Apple's CarPlay Audio entitlement. `ExtensionTemplates/CarPlayTemplate.swift` is a starting template after that entitlement is available.

## Dynamic Island / Lock Screen

The app uses `MPNowPlayingInfoCenter` and `MPRemoteCommandCenter`, which is the standard iOS media integration for Lock Screen, Control Center, Bluetooth accessories and supported Dynamic Island media presentation. The exact Dynamic Island UI is controlled by iOS.

## Alternate app icon

The Settings screen contains an alternate-icon toggle for an asset called `RapIcon`. To use it, add an alternate app icon named `RapIcon` to your Xcode asset/icon configuration. If the asset is not configured, iOS simply cannot switch to it.

## DRM note

Apple Music subscription offline downloads are DRM-protected and cannot be imported as ordinary audio files. Purchased AAC files and normal M4A/MP3/AAC/FLAC files are the intended input.
