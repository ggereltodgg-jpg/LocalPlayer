# V2.4 Sort + Smoothness Patch

- Added Library sorting: Title A-Z/Z-A, Artist, Album, Date Added, Release Year, Recently Played, Most/Least Played, Duration, Favorites, Genre, BPM and Random Order.
- Sort choice is remembered between launches.
- Search + sort now runs on a background task instead of repeatedly sorting ~8,000 tracks on the UI thread.
- Cached visible-track results stop the Library from re-filtering/re-sorting every time playback progress changes.
- Library rows observe playback individually so the full song list no longer redraws every 0.25 seconds.
- Playback UI timer reduced to 0.5-second updates to cut unnecessary main-thread work.
- Listening time is accumulated in memory instead of mutating/publishing the full track array every playback tick.
- Routine stats/favorite updates use a debounced background JSON save instead of encoding the entire library immediately.
- Imported artwork is loaded asynchronously and cached in memory to reduce scrolling hitching.
- Existing V2.3 manual iTunes sync and Mix fixes remain unchanged.

# V2.3.1 Mix Fix

- Fixed Smart Mix / Smart Shuffle freezing on very large (8k+) libraries by replacing the O(n²) shuffle path with an artist-bucket algorithm.
- Mix playback now skips temporarily unavailable restored iTunes items instead of stopping silently on the first track.
- Hard Rap and Gym mixes now work even when iTunes files do not contain BPM metadata.
- Chill / R&B filtering no longer repeatedly rebuilds/searches the Late Night array.
- iPhone Music sync now stores release year when available, so This Year can populate.
- No automatic full iTunes resync on app launch; cached library behavior from V2.3 remains.

# V2.2 Performance Patch

- Fast iTunes/iPhone Music sync for very large libraries (8,000+ songs)
- Stops publishing the track array once per song; publishes once after indexing
- Removes per-track filesystem size checks during Media Library sync
- Removes 900x900 artwork rendering/writes during sync
- Loads artwork lazily only for visible rows and player screens
- Adds bounded in-memory album-art cache
- Reduces sync status UI updates from every 50 tracks to every 250 tracks

# LocalRapPlayer 2.1 — iTunes / iPhone Music Sync

- Reads songs already synced to the iPhone with iTunes via `MPMediaLibrary`.
- One-time Media Library permission prompt.
- Automatically refreshes the synced iPhone Music library on app launch after permission is granted.
- Manual **Sync iPhone Music** button in Library and the + menu.
- Does not duplicate audio into the app sandbox; media-library songs are referenced by persistent ID.
- Imports title, artist, album, genre, track/disc number, duration, BPM when available, and album artwork.
- Existing Favorites, ratings, play counts and listening stats are preserved across resyncs.
- Apple Music subscription/DRM-protected or cloud-only tracks that do not expose a local asset URL are skipped.
- Synced songs can use EQ, crossfade and local analysis when iOS exposes a readable local audio asset.
- Hiding a synced song keeps it out of later rescans; **Restore Hidden Synced Songs** brings them back.

# Build Fix 1

Fixed compile errors found in GitHub Actions/Xcode 26.6 logs:

- Removed redundant optional bindings in `MusicLibrary.swift` for AVMetadataItem async loads.
- Replaced mixed `.tint` / `.secondary` ShapeStyle ternaries with explicit `Color` values in `NowPlayingView.swift`.
- Fixed weak `self` capture lifetime/mutation issue in crossfade task in `PlayerManager.swift`.

The existing `project.yml` and folder layout are unchanged.


## V2.3 — Instant Launch / Manual iTunes Sync
- Removed full iPhone/iTunes library rescan from app startup.
- Cached synced songs load immediately on launch.
- Full iTunes refresh only happens when **Sync iPhone Music** is tapped.
- Added last-sync timestamp and clearer cached-library status.
- Designed for very large restored/synced libraries (8,000+ songs).


## V2.4.1 — Seek / scrub fix
- Fixed dragging the Now Playing progress slider causing a different queue song to appear.
- Slider now previews the scrub position and seeks only once when the finger is released.
- Added playback-generation guards so stale AVAudioPlayerNode completion callbacks from a stopped segment cannot call Next after a seek.
- A failed seek on a restored iTunes item now keeps the same current track instead of skipping forward through the queue.
- Seeking a paused track keeps it paused.
