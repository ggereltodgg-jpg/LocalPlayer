import Foundation
import AVFoundation

@MainActor
final class MusicLibrary: ObservableObject {
    @Published private(set) var tracks: [Track] = []
    @Published var isImporting = false
    @Published var importStatus = ""
    @Published var analysisProgress = ""

    init() { load() }

    var favorites: [Track] { tracks.filter(\.isFavorite) }
    var recentlyAdded: [Track] { Array(tracks.sorted { $0.dateAdded > $1.dateAdded }.prefix(200)) }
    var mostPlayed: [Track] { Array(tracks.filter { $0.playCount > 0 }.sorted { $0.playCount > $1.playCount }.prefix(200)) }
    var neverPlayed: [Track] { tracks.filter { $0.playCount == 0 } }
    var recentlyPlayed: [Track] { Array(tracks.filter { $0.lastPlayed != nil }.sorted { ($0.lastPlayed ?? .distantPast) > ($1.lastPlayed ?? .distantPast) }.prefix(200)) }
    var artists: [String] { Array(Set(tracks.map(\.artist))).sorted { $0.localizedCaseInsensitiveCompare($1) == .orderedAscending } }
    var albums: [String] { Array(Set(tracks.map(\.album).filter { !$0.isEmpty })).sorted { $0.localizedCaseInsensitiveCompare($1) == .orderedAscending } }
    var folders: [String] { Array(Set(tracks.compactMap(\.relativeSourcePath).map { URL(fileURLWithPath: $0).deletingLastPathComponent().path })).sorted() }

    func tracks(forArtist artist: String) -> [Track] { tracks.filter { $0.artist == artist } }
    func tracks(forAlbum album: String) -> [Track] { tracks.filter { $0.album == album }.sorted { ($0.trackNumber ?? 9999) < ($1.trackNumber ?? 9999) } }
    func tracks(inFolder folder: String) -> [Track] { tracks.filter { ($0.relativeSourcePath.map { URL(fileURLWithPath: $0).deletingLastPathComponent().path }) == folder } }

    func importFiles(_ urls: [URL]) async {
        guard !urls.isEmpty else { return }
        isImporting = true
        defer { isImporting = false }
        var imported = 0, skipped = 0
        for (index, url) in urls.enumerated() {
            importStatus = "Importing \(index + 1) / \(urls.count)…"
            if await importOne(url) { imported += 1 } else { skipped += 1 }
        }
        sortLibrary(); save()
        importStatus = "Done: \(imported) imported, \(skipped) skipped"
    }

    func importFolder(_ folderURL: URL) async {
        isImporting = true
        defer { isImporting = false }
        importStatus = "Scanning folder…"
        let didAccess = folderURL.startAccessingSecurityScopedResource()
        defer { if didAccess { folderURL.stopAccessingSecurityScopedResource() } }
        let allowed = Set(["m4a", "mp3", "aac", "flac", "wav", "aif", "aiff", "caf"])
        guard let enumerator = FileManager.default.enumerator(at: folderURL, includingPropertiesForKeys: [.isRegularFileKey], options: [.skipsHiddenFiles, .skipsPackageDescendants]) else {
            importStatus = "Could not read folder"; return
        }
        var audioURLs: [URL] = []
        for case let u as URL in enumerator where allowed.contains(u.pathExtension.lowercased()) { audioURLs.append(u) }
        var imported = 0, skipped = 0
        for (index, url) in audioURLs.enumerated() {
            importStatus = "Importing \(index + 1) / \(audioURLs.count)…"
            let rel = url.path.replacingOccurrences(of: folderURL.path + "/", with: "")
            if await importOne(url, alreadySecurityScoped: true, relativePath: rel) { imported += 1 } else { skipped += 1 }
        }
        sortLibrary(); save()
        importStatus = "Done: \(imported) imported, \(skipped) skipped"
    }

    private func importOne(_ sourceURL: URL, alreadySecurityScoped: Bool = false, relativePath: String? = nil) async -> Bool {
        var didAccess = false
        if !alreadySecurityScoped { didAccess = sourceURL.startAccessingSecurityScopedResource() }
        defer { if didAccess { sourceURL.stopAccessingSecurityScopedResource() } }
        let attrs = try? FileManager.default.attributesOfItem(atPath: sourceURL.path)
        let size = (attrs?[.size] as? NSNumber)?.int64Value ?? 0
        let original = sourceURL.lastPathComponent
        if tracks.contains(where: { $0.originalFileName == original && $0.fileSize == size }) { return false }
        let ext = sourceURL.pathExtension.isEmpty ? "m4a" : sourceURL.pathExtension.lowercased()
        let storedName = "\(UUID().uuidString).\(ext)"
        let destination = AppPaths.musicDirectory.appendingPathComponent(storedName)
        do { try FileManager.default.copyItem(at: sourceURL, to: destination) } catch { return false }
        let metadata = await readMetadata(from: destination, fallbackName: sourceURL.deletingPathExtension().lastPathComponent)
        var artworkName: String?
        if let artwork = metadata.artworkData {
            let name = "\(UUID().uuidString).img"
            if (try? artwork.write(to: AppPaths.artworkDirectory.appendingPathComponent(name), options: .atomic)) != nil { artworkName = name }
        }
        tracks.append(Track(
            title: metadata.title, artist: metadata.artist, album: metadata.album, albumArtist: metadata.albumArtist,
            genre: metadata.genre, year: metadata.year, trackNumber: metadata.trackNumber, discNumber: metadata.discNumber,
            duration: metadata.duration, fileName: storedName, originalFileName: original, relativeSourcePath: relativePath,
            fileSize: size, artworkFileName: artworkName, bpm: metadata.bpm
        ))
        return true
    }

    private struct ParsedMetadata {
        var title: String; var artist: String; var album: String; var albumArtist: String; var genre: String
        var year: Int?; var trackNumber: Int?; var discNumber: Int?; var duration: Double; var artworkData: Data?; var bpm: Double?
    }

    private func readMetadata(from url: URL, fallbackName: String) async -> ParsedMetadata {
        let asset = AVURLAsset(url: url)
        var title = fallbackName, artist = "Unknown Artist", album = "", albumArtist = "", genre = ""
        var year: Int?, trackNumber: Int?, discNumber: Int?, artwork: Data?, bpm: Double?, durationSeconds = 0.0
        do {
            let metadata = try await asset.load(.metadata)
            for item in metadata {
                let key = (item.commonKey?.rawValue ?? "").lowercased()
                let identifier = item.identifier?.rawValue.lowercased() ?? ""
                if key.contains("title"), let v = try? await item.load(.stringValue), let v, !v.isEmpty { title = v }
                else if key.contains("artist"), let v = try? await item.load(.stringValue), let v, !v.isEmpty { artist = v }
                else if key.contains("albumname"), let v = try? await item.load(.stringValue), let v { album = v }
                else if key.contains("artwork"), let v = try? await item.load(.dataValue), let v { artwork = v }
                else if identifier.contains("genre"), let v = try? await item.load(.stringValue), let v { genre = v }
                else if identifier.contains("albumartist"), let v = try? await item.load(.stringValue), let v { albumArtist = v }
                else if identifier.contains("year") || identifier.contains("creationdate"), let v = try? await item.load(.stringValue), let v { year = Int(v.prefix(4)) }
                else if identifier.contains("tracknumber"), let v = try? await item.load(.numberValue), let v { trackNumber = v.intValue }
                else if identifier.contains("discnumber"), let v = try? await item.load(.numberValue), let v { discNumber = v.intValue }
                else if identifier.contains("tempo"), let v = try? await item.load(.numberValue), let v { bpm = v.doubleValue }
            }
            let duration = try await asset.load(.duration)
            durationSeconds = duration.seconds.isFinite ? duration.seconds : 0
        } catch { }
        return ParsedMetadata(title: title, artist: artist, album: album, albumArtist: albumArtist, genre: genre, year: year, trackNumber: trackNumber, discNumber: discNumber, duration: durationSeconds, artworkData: artwork, bpm: bpm)
    }

    func toggleFavorite(_ track: Track) { update(track.id) { $0.isFavorite.toggle() } }
    func setRating(_ track: Track, rating: Int) { update(track.id) { $0.rating = max(0, min(5, rating)) } }
    func markPlayed(_ trackID: UUID) { update(trackID) { $0.playCount += 1; $0.lastPlayed = Date() } }
    func markSkipped(_ trackID: UUID) { update(trackID) { $0.skipCount += 1 } }
    func addListenTime(_ trackID: UUID, seconds: Double) { guard seconds > 0 else { return }; update(trackID, saveImmediately: false) { $0.totalListenSeconds += seconds } }

    func updateMetadata(_ trackID: UUID, title: String, artist: String, album: String, genre: String, year: Int?, bpm: Double?, key: String?) {
        update(trackID) { t in
            t.title = title; t.artist = artist; t.album = album; t.genre = genre; t.year = year; t.bpm = bpm; t.musicalKey = key
        }
        sortLibrary()
    }

    func attachLyrics(_ url: URL, to trackID: UUID) {
        let access = url.startAccessingSecurityScopedResource(); defer { if access { url.stopAccessingSecurityScopedResource() } }
        let ext = url.pathExtension.isEmpty ? "lrc" : url.pathExtension
        let name = "\(UUID().uuidString).\(ext)"
        let dest = AppPaths.lyricsDirectory.appendingPathComponent(name)
        do { try FileManager.default.copyItem(at: url, to: dest); update(trackID) { $0.lyricsFileName = name } } catch { }
    }

    func lyricsText(for track: Track) -> String? {
        guard let url = AppPaths.lyricsURL(for: track) else { return nil }
        return try? String(contentsOf: url, encoding: .utf8)
    }

    func rebuildArtwork(_ track: Track) async {
        let metadata = await readMetadata(from: AppPaths.audioURL(for: track), fallbackName: track.title)
        guard let data = metadata.artworkData else { return }
        let name = "\(UUID().uuidString).img"
        let url = AppPaths.artworkDirectory.appendingPathComponent(name)
        guard (try? data.write(to: url, options: .atomic)) != nil else { return }
        if let old = AppPaths.artworkURL(for: track) { try? FileManager.default.removeItem(at: old) }
        update(track.id) { $0.artworkFileName = name }
    }

    func analyze(_ track: Track) async {
        analysisProgress = "Analyzing \(track.title)…"
        let url = AppPaths.audioURL(for: track)
        let result = await Task.detached(priority: .utility) { try? AudioAnalyzer.analyze(url: url) }.value
        if let result { update(track.id) { $0.bpm = result.bpm; $0.musicalKey = result.key; $0.replayGainDB = result.replayGainDB } }
        analysisProgress = ""
    }

    func analyzeAllMissing(limit: Int? = nil) async {
        let candidates = tracks.filter { $0.bpm == nil || $0.musicalKey == nil || $0.replayGainDB == nil }
        let work = limit.map { Array(candidates.prefix($0)) } ?? candidates
        for (i, track) in work.enumerated() {
            analysisProgress = "Analyzing \(i + 1) / \(work.count)…"
            let url = AppPaths.audioURL(for: track)
            let result = await Task.detached(priority: .utility) { try? AudioAnalyzer.analyze(url: url) }.value
            if let result { update(track.id, saveImmediately: false) { $0.bpm = result.bpm; $0.musicalKey = result.key; $0.replayGainDB = result.replayGainDB } }
        }
        save(); analysisProgress = "Done"
    }

    func delete(_ track: Track) {
        if let url = AppPaths.artworkURL(for: track) { try? FileManager.default.removeItem(at: url) }
        if let url = AppPaths.lyricsURL(for: track) { try? FileManager.default.removeItem(at: url) }
        try? FileManager.default.removeItem(at: AppPaths.audioURL(for: track))
        tracks.removeAll { $0.id == track.id }; save()
    }

    var missingFiles: [Track] { tracks.filter { !FileManager.default.fileExists(atPath: AppPaths.audioURL(for: $0).path) } }

    var duplicateGroups: [[Track]] {
        Dictionary(grouping: tracks) { normalized($0.artist) + "|" + normalized($0.title) }
            .values.filter { $0.count > 1 }.sorted { $0.count > $1.count }
    }

    func importPlaylistFile(_ url: URL, playlistStore: PlaylistStore) {
        let access = url.startAccessingSecurityScopedResource(); defer { if access { url.stopAccessingSecurityScopedResource() } }
        let ext = url.pathExtension.lowercased()
        if ext == "m3u" || ext == "m3u8" {
            guard let text = try? String(contentsOf: url, encoding: .utf8) else { return }
            let names = text.components(separatedBy: .newlines).filter { !$0.isEmpty && !$0.hasPrefix("#") }.map { URL(fileURLWithPath: $0).lastPathComponent.lowercased() }
            let ids = names.compactMap { name in tracks.first(where: { $0.originalFileName.lowercased() == name })?.id }
            playlistStore.appendImported(name: url.deletingPathExtension().lastPathComponent, trackIDs: ids)
            return
        }
        if ext == "xml" {
            guard let data = try? Data(contentsOf: url),
                  let object = try? PropertyListSerialization.propertyList(from: data, format: nil),
                  let plist = object as? [String: Any],
                  let trackDict = plist["Tracks"] as? [String: [String: Any]],
                  let pls = plist["Playlists"] as? [[String: Any]] else { return }
            var idToLocal: [Int: UUID] = [:]
            for (_, info) in trackDict {
                guard let tid = info["Track ID"] as? Int else { continue }
                let name = (info["Name"] as? String ?? "").lowercased()
                let artist = (info["Artist"] as? String ?? "").lowercased()
                if let match = tracks.first(where: { normalized($0.title) == normalized(name) && normalized($0.artist) == normalized(artist) }) { idToLocal[tid] = match.id }
                else if let loc = info["Location"] as? String, let u = URL(string: loc), let match = tracks.first(where: { $0.originalFileName.lowercased() == u.lastPathComponent.lowercased() }) { idToLocal[tid] = match.id }
            }
            for p in pls {
                guard let name = p["Name"] as? String, let items = p["Playlist Items"] as? [[String: Any]] else { continue }
                let ids = items.compactMap { ($0["Track ID"] as? Int).flatMap { idToLocal[$0] } }
                if !ids.isEmpty { playlistStore.appendImported(name: name, trackIDs: ids) }
            }
        }
    }

    func makeBackup(playlists: [Playlist]) -> URL? {
        let trackBackups = tracks.map { t in TrackBackup(originalFileName: t.originalFileName, title: t.title, artist: t.artist, album: t.album, isFavorite: t.isFavorite, rating: t.rating, playCount: t.playCount, skipCount: t.skipCount, totalListenSeconds: t.totalListenSeconds, bpm: t.bpm, musicalKey: t.musicalKey, replayGainDB: t.replayGainDB) }
        let byID = Dictionary(uniqueKeysWithValues: tracks.map { ($0.id, $0.originalFileName) })
        let playlistBackups = playlists.map { PlaylistBackup(name: $0.name, originalFileNames: $0.trackIDs.compactMap { byID[$0] }) }
        let payload = LibraryBackup(createdAt: Date(), tracks: trackBackups, playlists: playlistBackups)
        guard let data = try? JSONEncoder().encode(payload) else { return nil }
        let url = AppPaths.exportDirectory.appendingPathComponent("LocalRapPlayer_Backup.json")
        try? data.write(to: url, options: .atomic)
        return url
    }

    func restoreBackup(_ url: URL, playlistStore: PlaylistStore) {
        let access = url.startAccessingSecurityScopedResource(); defer { if access { url.stopAccessingSecurityScopedResource() } }
        guard let data = try? Data(contentsOf: url), let backup = try? JSONDecoder().decode(LibraryBackup.self, from: data) else { return }
        let backupByName = Dictionary(uniqueKeysWithValues: backup.tracks.map { ($0.originalFileName.lowercased(), $0) })
        for i in tracks.indices {
            if let b = backupByName[tracks[i].originalFileName.lowercased()] {
                tracks[i].isFavorite = b.isFavorite; tracks[i].rating = b.rating; tracks[i].playCount = b.playCount; tracks[i].skipCount = b.skipCount
                tracks[i].totalListenSeconds = b.totalListenSeconds; tracks[i].bpm = b.bpm; tracks[i].musicalKey = b.musicalKey; tracks[i].replayGainDB = b.replayGainDB
            }
        }
        let localByName = Dictionary(uniqueKeysWithValues: tracks.map { ($0.originalFileName.lowercased(), $0.id) })
        let restored = backup.playlists.map { Playlist(name: $0.name, trackIDs: $0.originalFileNames.compactMap { localByName[$0.lowercased()] }) }
        playlistStore.replaceAll(restored); save()
    }

    func flushStats() { save() }

    private func update(_ id: UUID, saveImmediately: Bool = true, _ body: (inout Track) -> Void) {
        guard let i = tracks.firstIndex(where: { $0.id == id }) else { return }
        body(&tracks[i]); if saveImmediately { save() }
    }

    private func normalized(_ value: String) -> String {
        value.folding(options: [.diacriticInsensitive, .caseInsensitive], locale: .current).trimmingCharacters(in: .whitespacesAndNewlines)
    }

    private func sortLibrary() {
        tracks.sort { a, b in
            if a.artist.localizedCaseInsensitiveCompare(b.artist) == .orderedSame { return a.title.localizedCaseInsensitiveCompare(b.title) == .orderedAscending }
            return a.artist.localizedCaseInsensitiveCompare(b.artist) == .orderedAscending
        }
    }

    private func load() {
        guard let data = try? Data(contentsOf: AppPaths.libraryFile), let decoded = try? JSONDecoder().decode([Track].self, from: data) else { return }
        tracks = decoded
    }

    private func save() {
        guard let data = try? JSONEncoder().encode(tracks) else { return }
        try? data.write(to: AppPaths.libraryFile, options: .atomic)
    }
}
